/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Viture Glasses SDK", "index.html", [
    [ "Release Notes", "release_notes.html", [
      [ "v2.1.0", "release_v210.html", [
        [ "New Features", "release_v210.html#autotoc_md5", null ]
      ] ],
      [ "v2.1.1", "release_v211.html", [
        [ "Changes", "release_v211.html#autotoc_md6", null ]
      ] ],
      [ "v2.1.2", "release_v212.html", [
        [ "Changes", "release_v212.html#autotoc_md7", null ]
      ] ],
      [ "v2.2.0", "release_v220.html", [
        [ "New Features", "release_v220.html#autotoc_md8", null ],
        [ "Bug Fixes", "release_v220.html#autotoc_md9", null ]
      ] ],
      [ "v2.2.1", "release_v221.html", [
        [ "New Features", "release_v221.html#autotoc_md10", null ],
        [ "Bug Fixes", "release_v221.html#autotoc_md11", null ],
        [ "Breaking Changes", "release_v221.html#autotoc_md12", null ]
      ] ],
      [ "v2.3.0", "release_v230.html", [
        [ "New Features", "release_v230.html#autotoc_md13", null ],
        [ "Bug Fixes", "release_v230.html#autotoc_md14", null ],
        [ "Known Limitations on Beast", "release_v230.html#autotoc_md15", null ]
      ] ],
      [ "v2.3.1", "release_v231.html", [
        [ "Bug Fixes", "release_v231.html#autotoc_md16", null ],
        [ "API Changes", "release_v231.html#autotoc_md17", null ],
        [ "Known Limitations on Beast", "release_v231.html#autotoc_md18", null ]
      ] ],
      [ "v2.3.2", "release_v232.html", [
        [ "New APIs", "release_v232.html#autotoc_md19", null ],
        [ "Bug Fixes", "release_v232.html#autotoc_md20", null ],
        [ "Compatibility", "release_v232.html#autotoc_md21", null ]
      ] ],
      [ "v2.4.0", "release_v240.html", [
        [ "Web SDK (new)", "release_v240.html#autotoc_md22", null ],
        [ "New APIs", "release_v240.html#autotoc_md23", null ],
        [ "New Constants", "release_v240.html#autotoc_md24", null ],
        [ "New Features", "release_v240.html#autotoc_md25", null ],
        [ "Bug Fixes", "release_v240.html#autotoc_md26", null ],
        [ "Documentation", "release_v240.html#autotoc_md27", null ],
        [ "Compatibility", "release_v240.html#autotoc_md28", null ]
      ] ],
      [ "v2.4.1", "release_v241.html", [
        [ "New device support", "release_v241.html#autotoc_md0", null ],
        [ "New APIs", "release_v241.html#autotoc_md1", null ],
        [ "New Constants", "release_v241.html#autotoc_md2", null ],
        [ "Bug Fixes", "release_v241.html#autotoc_md3", null ],
        [ "Compatibility", "release_v241.html#autotoc_md4", null ]
      ] ]
    ] ],
    [ "VITURE Glasses SDK Documentation", "page_overview.html", [
      [ "Supported Hardware", "page_overview.html#autotoc_md30", null ],
      [ "Supported Platforms", "page_overview.html#autotoc_md32", null ],
      [ "Documentation Guide", "page_overview.html#autotoc_md34", null ],
      [ "Five-Minute Overview", "page_overview.html#autotoc_md36", null ],
      [ "Headers at a Glance", "page_overview.html#autotoc_md38", null ],
      [ "SDK Version", "page_overview.html#autotoc_md40", null ],
      [ "Core Concepts", "page_concepts.html", [
        [ "The Handle: XRDeviceProviderHandle", "page_concepts.html#autotoc_md43", null ],
        [ "Device Families", "page_concepts.html#autotoc_md45", null ],
        [ "Lifecycle States", "page_concepts.html#autotoc_md47", null ],
        [ "Callbacks vs. Polling", "page_concepts.html#autotoc_md49", [
          [ "Gen1 / Gen2 — Callback Model", "page_concepts.html#autotoc_md50", null ],
          [ "Carina — Polling Model", "page_concepts.html#autotoc_md51", null ]
        ] ],
        [ "Coordinate Systems", "page_concepts.html#autotoc_md53", null ],
        [ "Threading Model", "page_concepts.html#autotoc_md55", null ],
        [ "Error Handling", "page_concepts.html#autotoc_md57", null ],
        [ "Logging", "page_concepts.html#autotoc_md59", null ]
      ] ],
      [ "Quick Start — Desktop (C++)", "page_quickstart.html", [
        [ "Prerequisites", "page_quickstart.html#autotoc_md61", [
          [ "Linux udev Rule", "page_quickstart.html#autotoc_md62", null ]
        ] ],
        [ "CMake Setup", "page_quickstart.html#autotoc_md64", null ],
        [ "Step 1 — Find a Connected Device", "page_quickstart.html#autotoc_md66", [
          [ "Luma Ultra", "page_quickstart.html#autotoc_md67", null ]
        ] ],
        [ "Step 2 — Create the Provider", "page_quickstart.html#autotoc_md69", null ],
        [ "Step 3 — Check Device Type", "page_quickstart.html#autotoc_md71", null ],
        [ "Step 4 — Register Callbacks (Gen1 / Gen2 only)", "page_quickstart.html#autotoc_md73", null ],
        [ "Step 5 — Initialize and Start", "page_quickstart.html#autotoc_md75", null ],
        [ "Step 6 — Enable IMU or Start Pose Polling", "page_quickstart.html#autotoc_md77", null ],
        [ "Step 7 — Cleanup", "page_quickstart.html#autotoc_md79", null ],
        [ "Complete Minimal Example", "page_quickstart.html#autotoc_md81", null ],
        [ "Next Steps", "page_quickstart.html#autotoc_md83", null ]
      ] ],
      [ "Head Tracking", "page_head_tracking.html", [
        [ "Which API Should I Use?", "page_head_tracking.html#autotoc_md85", null ],
        [ "Gen1 / Gen2 — IMU Callbacks", "page_head_tracking.html#autotoc_md87", [
          [ "Two Callback Modes", "page_head_tracking.html#autotoc_md88", null ],
          [ "Pose Callback", "page_head_tracking.html#autotoc_md89", null ],
          [ "Raw Callback", "page_head_tracking.html#autotoc_md90", null ],
          [ "Enabling the IMU", "page_head_tracking.html#autotoc_md91", null ],
          [ "Disabling the IMU", "page_head_tracking.html#autotoc_md92", null ],
          [ "Sharing Pose Data with the Render Thread", "page_head_tracking.html#autotoc_md93", null ],
          [ "Coordinate Conversion: NWU to OpenGL", "page_head_tracking.html#autotoc_md94", null ]
        ] ],
        [ "Carina (Luma Ultra) — 6DoF Pose Polling", "page_head_tracking.html#autotoc_md96", [
          [ "Setting DOF Mode", "page_head_tracking.html#autotoc_md97", null ],
          [ "Polling the Pose", "page_head_tracking.html#autotoc_md98", null ],
          [ "Pose Prediction", "page_head_tracking.html#autotoc_md99", null ],
          [ "Polling Rate", "page_head_tracking.html#autotoc_md100", null ],
          [ "Recentering and Resetting", "page_head_tracking.html#autotoc_md101", null ],
          [ "Carina Optional Callbacks", "page_head_tracking.html#autotoc_md102", null ]
        ] ],
        [ "Switching Between 3DOF and 6DOF (Carina)", "page_head_tracking.html#autotoc_md104", null ],
        [ "Summary: Gen1/Gen2 vs. Carina", "page_head_tracking.html#autotoc_md106", null ]
      ] ],
      [ "Device Control", "page_device_control.html", [
        [ "State Change Notifications", "page_device_control.html#autotoc_md108", null ],
        [ "Brightness", "page_device_control.html#autotoc_md110", [
          [ "Value Ranges", "page_device_control.html#ValueRanges", null ],
          [ "Read", "page_device_control.html#autotoc_md111", null ],
          [ "Write", "page_device_control.html#autotoc_md112", null ]
        ] ],
        [ "Volume", "page_device_control.html#autotoc_md114", [
          [ "Value Ranges", "page_device_control.html#autotoc_md115", null ],
          [ "Read / Write", "page_device_control.html#autotoc_md116", null ]
        ] ],
        [ "Querying Value Limits", "page_device_control.html#autotoc_md118", null ],
        [ "Display Mode", "page_device_control.html#autotoc_md120", [
          [ "Standard Display Modes", "page_device_control.html#autotoc_md121", null ],
          [ "Read / Write", "page_device_control.html#autotoc_md122", null ],
          [ "Convenience: 2D / 3D Toggle", "page_device_control.html#autotoc_md123", null ],
          [ "Default Power-On Mode", "page_device_control.html#autotoc_md124", null ],
          [ "Hardware Button Lock", "page_device_control.html#autotoc_md125", null ]
        ] ],
        [ "Electrochromic Film", "page_device_control.html#autotoc_md127", [
          [ "Behavior by Device Generation", "page_device_control.html#autotoc_md128", null ],
          [ "Read / Write", "page_device_control.html#autotoc_md129", null ]
        ] ],
        [ "Wear Status", "page_device_control.html#autotoc_md131", [
          [ "Read", "page_device_control.html#autotoc_md132", null ],
          [ "Change Notifications", "page_device_control.html#autotoc_md133", null ]
        ] ],
        [ "Beast (Gen2) — Native Mode", "page_device_control.html#autotoc_md135", [
          [ "Mode: Bypass vs. Native", "page_device_control.html#autotoc_md136", null ],
          [ "Native Display Mode", "page_device_control.html#autotoc_md137", null ],
          [ "Native DOF", "page_device_control.html#autotoc_md138", null ],
          [ "Native Display Size and Distance", "page_device_control.html#autotoc_md139", null ],
          [ "Native 2D / 3D Toggle", "page_device_control.html#autotoc_md140", null ]
        ] ],
        [ "Display Duty Cycle (Advanced)", "page_device_control.html#autotoc_md142", null ],
        [ "Practical Example", "page_device_control.html#autotoc_md144", [
          [ "General Device Setup", "page_device_control.html#autotoc_md145", null ],
          [ "Beast — Switching to Bypass Mode", "page_device_control.html#autotoc_md146", null ],
          [ "Beast — Switching Back to Native Mode", "page_device_control.html#autotoc_md147", null ]
        ] ]
      ] ],
      [ "Camera Streaming", "page_camera.html", [
        [ "Camera Overview", "page_camera.html#autotoc_md149", null ],
        [ "Pass-Through Camera (UVC)", "page_camera.html#autotoc_md151", [
          [ "Step 1 — Discover the Camera VID/PID", "page_camera.html#autotoc_md152", null ],
          [ "Step 2 — Create the Camera Provider", "page_camera.html#autotoc_md153", null ],
          [ "Step 3 — Start Streaming", "page_camera.html#autotoc_md154", null ],
          [ "Step 4 — Decoding MJPEG", "page_camera.html#autotoc_md155", null ],
          [ "Step 5 — Stop and Destroy", "page_camera.html#autotoc_md156", null ],
          [ "Checking Streaming State", "page_camera.html#autotoc_md157", null ],
          [ "Complete Pass-Through Camera Example", "page_camera.html#autotoc_md158", null ]
        ] ],
        [ "Stereo Tracking Cameras (Carina / Luma Ultra only)", "page_camera.html#autotoc_md160", [
          [ "Registering the Stereo Callback", "page_camera.html#autotoc_md161", null ],
          [ "Exposure Control", "page_camera.html#autotoc_md162", null ]
        ] ],
        [ "</blockquote>", "page_camera.html#autotoc_md163", null ],
        [ "Choosing the Right Camera", "page_camera.html#autotoc_md164", null ]
      ] ],
      [ "Android Integration Guide", "page_android.html", [
        [ "How Android Differs from Desktop", "page_android.html#autotoc_md166", null ],
        [ "AndroidManifest.xml", "page_android.html#autotoc_md168", null ],
        [ "USB Permission Flow", "page_android.html#autotoc_md170", [
          [ "Kotlin Implementation", "page_android.html#autotoc_md171", null ]
        ] ],
        [ "JNI Bridge Pattern", "page_android.html#autotoc_md173", null ],
        [ "CMake Configuration for Android", "page_android.html#autotoc_md175", null ],
        [ "Carina Pose Polling on Android", "page_android.html#autotoc_md177", null ],
        [ "Camera on Android (Android 14+)", "page_android.html#autotoc_md179", null ],
        [ "Full Sequence Diagram", "page_android.html#autotoc_md181", null ]
      ] ],
      [ "SDK Usage Reporting (Stat Reporter)", "page_stat_reporter.html", [
        [ "When to Use", "page_stat_reporter.html#autotoc_md183", null ],
        [ "Lifecycle", "page_stat_reporter.html#autotoc_md185", null ],
        [ "Network Behaviour", "page_stat_reporter.html#autotoc_md187", null ],
        [ "Return Codes", "page_stat_reporter.html#autotoc_md189", null ],
        [ "Minimal Example", "page_stat_reporter.html#autotoc_md191", null ]
      ] ],
      [ "Native-DOF Devices", "page_native_dof_devices.html", [
        [ "Capability Detection", "page_native_dof_devices.html#autotoc_md193", null ],
        [ "Display Mode: Two Disjoint Sets", "page_native_dof_devices.html#autotoc_md195", null ],
        [ "DOF Selector", "page_native_dof_devices.html#autotoc_md197", null ],
        [ "Recommended Logic Flow", "page_native_dof_devices.html#autotoc_md199", null ],
        [ "Things That Are <em>Not</em> Tied to Native DOF", "page_native_dof_devices.html#autotoc_md201", null ],
        [ "Quick Reference", "page_native_dof_devices.html#autotoc_md203", null ]
      ] ]
    ] ],
    [ "API Reference", "page_api_reference.html", [
      [ "viture_glasses_provider.h", "api_glasses_provider.html", [
        [ "Types", "api_glasses_provider.html#autotoc_md204", [
          [ "<tt>XRDeviceProviderHandle</tt>", "api_glasses_provider.html#autotoc_md205", null ],
          [ "<tt>GlassStateCallback</tt>", "api_glasses_provider.html#autotoc_md206", null ],
          [ "<tt>LogHook</tt>", "api_glasses_provider.html#autotoc_md207", null ],
          [ "<tt>XRDeviceType</tt>", "api_glasses_provider.html#autotoc_md208", null ]
        ] ],
        [ "Required Call Order", "api_glasses_provider.html#autotoc_md209", null ],
        [ "Functions", "api_glasses_provider.html#autotoc_md210", [
          [ "<tt>xr_device_provider_create</tt>", "api_glasses_provider.html#autotoc_md211", null ],
          [ "<tt>xr_device_provider_initialize</tt>", "api_glasses_provider.html#autotoc_md212", null ],
          [ "<tt>xr_device_provider_start</tt>", "api_glasses_provider.html#autotoc_md213", null ],
          [ "<tt>xr_device_provider_stop</tt>", "api_glasses_provider.html#autotoc_md214", null ],
          [ "<tt>xr_device_provider_shutdown</tt>", "api_glasses_provider.html#autotoc_md215", null ],
          [ "<tt>xr_device_provider_destroy</tt>", "api_glasses_provider.html#autotoc_md216", null ],
          [ "<tt>xr_device_provider_get_thread_id</tt>", "api_glasses_provider.html#autotoc_md217", null ],
          [ "<tt>xr_device_provider_register_state_callback</tt>", "api_glasses_provider.html#autotoc_md218", null ],
          [ "<tt>xr_device_provider_get_device_type</tt>", "api_glasses_provider.html#autotoc_md219", null ],
          [ "<tt>xr_device_provider_is_product_id_valid</tt>", "api_glasses_provider.html#autotoc_md220", null ],
          [ "<tt>xr_device_provider_is_product_support_native_dof</tt>", "api_glasses_provider.html#autotoc_md221", null ],
          [ "<tt>xr_device_provider_is_product_support_imu_frequency</tt>", "api_glasses_provider.html#autotoc_md222", null ],
          [ "<tt>xr_device_provider_get_market_name</tt>", "api_glasses_provider.html#autotoc_md223", null ],
          [ "<tt>xr_device_provider_set_log_level</tt>", "api_glasses_provider.html#autotoc_md224", null ],
          [ "<tt>xr_device_provider_get_log_level</tt>", "api_glasses_provider.html#autotoc_md225", null ],
          [ "<tt>xr_device_provider_set_log_hook</tt>", "api_glasses_provider.html#autotoc_md226", null ]
        ] ]
      ] ],
      [ "viture_macros_public.h", "api_macros_public.html", [
        [ "VITURE api", "api_macros_public.html#autotoc_md227", null ],
        [ "Log Level Macros", "api_macros_public.html#autotoc_md228", null ]
      ] ],
      [ "viture_protocol_public.h", "api_protocol_public.html", [
        [ "Constants", "api_protocol_public.html#autotoc_md229", [
          [ "Product Market Names", "api_protocol_public.html#autotoc_md230", null ],
          [ "Result Codes", "api_protocol_public.html#autotoc_md231", null ],
          [ "Display Mode Identifiers", "api_protocol_public.html#autotoc_md232", null ],
          [ "Duty Cycle Presets", "api_protocol_public.html#autotoc_md233", null ],
          [ "Display Size Identifiers (for native 3DoF devices)", "api_protocol_public.html#autotoc_md234", null ],
          [ "Native DOF Modes (for native 3DoF devices)", "api_protocol_public.html#autotoc_md235", null ],
          [ "Display Modes for Native Mode (currently Beast only)", "api_protocol_public.html#autotoc_md236", null ],
          [ "IMU Configuration", "api_protocol_public.html#autotoc_md237", null ],
          [ "Callback Identifiers", "api_protocol_public.html#autotoc_md238", null ],
          [ "Callback Value Ranges", "api_protocol_public.html#autotoc_md239", null ],
          [ "Value Identifiers", "api_protocol_public.html#autotoc_md240", null ]
        ] ],
        [ "Functions", "api_protocol_public.html#autotoc_md241", [
          [ "<tt>xr_device_provider_get_film_mode</tt>", "api_protocol_public.html#autotoc_md242", null ],
          [ "<tt>xr_device_provider_set_film_mode</tt>", "api_protocol_public.html#autotoc_md243", null ],
          [ "<tt>xr_device_provider_get_duty_cycle</tt>", "api_protocol_public.html#autotoc_md244", null ],
          [ "<tt>xr_device_provider_set_duty_cycle</tt>", "api_protocol_public.html#autotoc_md245", null ],
          [ "<tt>xr_device_provider_get_wear_status</tt>", "api_protocol_public.html#autotoc_md246", null ],
          [ "<tt>xr_device_provider_get_display_mode</tt>", "api_protocol_public.html#autotoc_md247", null ],
          [ "<tt>xr_device_provider_set_display_mode</tt>", "api_protocol_public.html#autotoc_md248", null ],
          [ "<tt>xr_device_provider_set_default_display_mode</tt>", "api_protocol_public.html#autotoc_md249", null ],
          [ "<tt>xr_device_provider_set_display_mode_button_enabled</tt>", "api_protocol_public.html#autotoc_md250", null ],
          [ "<tt>xr_device_provider_native_get_mode</tt>", "api_protocol_public.html#autotoc_md251", null ],
          [ "<tt>xr_device_provider_native_set_mode</tt>", "api_protocol_public.html#autotoc_md252", null ],
          [ "<tt>xr_device_provider_native_get_display_mode</tt>", "api_protocol_public.html#autotoc_md253", null ],
          [ "<tt>xr_device_provider_native_set_display_mode</tt>", "api_protocol_public.html#autotoc_md254", null ],
          [ "<tt>xr_device_provider_native_get_side_mode</tt>", "api_protocol_public.html#autotoc_md255", null ],
          [ "<tt>xr_device_provider_native_set_side_mode</tt>", "api_protocol_public.html#autotoc_md256", null ],
          [ "<tt>xr_device_provider_native_switch_dimension</tt>", "api_protocol_public.html#autotoc_md257", null ],
          [ "<tt>xr_device_provider_native_get_dof</tt>", "api_protocol_public.html#autotoc_md258", null ],
          [ "<tt>xr_device_provider_native_set_dof</tt>", "api_protocol_public.html#autotoc_md259", null ],
          [ "<tt>xr_device_provider_native_recenter_dof</tt>", "api_protocol_public.html#autotoc_md260", null ],
          [ "<tt>xr_device_provider_native_get_display_distance</tt>", "api_protocol_public.html#autotoc_md261", null ],
          [ "<tt>xr_device_provider_native_set_display_distance</tt>", "api_protocol_public.html#autotoc_md262", null ],
          [ "<tt>xr_device_provider_native_get_display_size</tt>", "api_protocol_public.html#autotoc_md263", null ],
          [ "<tt>xr_device_provider_native_set_display_size</tt>", "api_protocol_public.html#autotoc_md264", null ],
          [ "<tt>xr_device_provider_switch_dimension</tt>", "api_protocol_public.html#autotoc_md265", null ],
          [ "<tt>xr_device_provider_get_brightness_level</tt>", "api_protocol_public.html#autotoc_md266", null ],
          [ "<tt>xr_device_provider_set_brightness_level</tt>", "api_protocol_public.html#autotoc_md267", null ],
          [ "<tt>xr_device_provider_get_volume_level</tt>", "api_protocol_public.html#autotoc_md268", null ],
          [ "<tt>xr_device_provider_set_volume_level</tt>", "api_protocol_public.html#autotoc_md269", null ],
          [ "<tt>xr_device_provider_get_value_max</tt>", "api_protocol_public.html#autotoc_md270", null ],
          [ "<tt>xr_device_provider_get_glasses_version</tt>", "api_protocol_public.html#autotoc_md271", null ],
          [ "<tt>xr_device_provider_get_sn_hash</tt>", "api_protocol_public.html#autotoc_md272", null ]
        ] ]
      ] ],
      [ "viture_device.h", "api_device.html", [
        [ "Callback Types", "api_device.html#autotoc_md273", [
          [ "<tt>VitureImuRawCallback</tt>", "api_device.html#autotoc_md274", null ],
          [ "<tt>VitureImuPoseCallback</tt>", "api_device.html#autotoc_md275", null ]
        ] ],
        [ "Functions", "api_device.html#autotoc_md276", [
          [ "<tt>xr_device_provider_register_imu_raw_callback</tt>", "api_device.html#autotoc_md277", null ],
          [ "<tt>xr_device_provider_register_imu_pose_callback</tt>", "api_device.html#autotoc_md278", null ],
          [ "<tt>xr_device_provider_open_imu</tt>", "api_device.html#autotoc_md279", null ],
          [ "<tt>xr_device_provider_close_imu</tt>", "api_device.html#autotoc_md280", null ]
        ] ]
      ] ],
      [ "viture_device_carina.h", "api_device_carina.html", [
        [ "Callback Types", "api_device_carina.html#autotoc_md281", [
          [ "<tt>XRPoseCallback</tt>", "api_device_carina.html#autotoc_md282", null ],
          [ "<tt>XRVSyncCallback</tt>", "api_device_carina.html#autotoc_md283", null ],
          [ "<tt>XRImuCallback</tt>", "api_device_carina.html#autotoc_md284", null ],
          [ "<tt>XRCameraCallback</tt>", "api_device_carina.html#autotoc_md285", null ]
        ] ],
        [ "Functions", "api_device_carina.html#autotoc_md286", [
          [ "<tt>xr_device_provider_register_callbacks_carina</tt>", "api_device_carina.html#autotoc_md287", null ],
          [ "<tt>xr_device_provider_set_dof_type_carina</tt>", "api_device_carina.html#autotoc_md288", null ],
          [ "<tt>xr_device_provider_reset_pose_carina</tt>", "api_device_carina.html#autotoc_md289", null ],
          [ "<tt>xr_device_provider_reset_origin_carina</tt>", "api_device_carina.html#autotoc_md290", null ],
          [ "<tt>xr_device_provider_get_gl_pose_carina</tt>", "api_device_carina.html#autotoc_md291", null ],
          [ "<tt>xr_device_provider_set_auto_exposure_carina</tt>", "api_device_carina.html#autotoc_md292", null ],
          [ "<tt>xr_device_provider_set_manual_exposure_carina</tt>", "api_device_carina.html#autotoc_md293", null ]
        ] ]
      ] ],
      [ "viture_camera_provider.h", "api_camera_provider.html", [
        [ "Overview", "api_camera_provider.html#autotoc_md294", null ],
        [ "Types", "api_camera_provider.html#autotoc_md295", [
          [ "<tt>XRCameraProviderHandle</tt>", "api_camera_provider.html#autotoc_md296", null ],
          [ "<tt>XRCameraFormat</tt>", "api_camera_provider.html#autotoc_md297", null ],
          [ "<tt>XRCameraFrame</tt>", "api_camera_provider.html#autotoc_md298", null ],
          [ "<tt>XRCameraFrameCallback</tt>", "api_camera_provider.html#autotoc_md299", null ]
        ] ],
        [ "Device Support", "api_camera_provider.html#autotoc_md300", null ],
        [ "Functions", "api_camera_provider.html#autotoc_md301", [
          [ "<tt>xr_camera_provider_get_camera_vid</tt>", "api_camera_provider.html#autotoc_md302", null ],
          [ "<tt>xr_camera_provider_get_camera_pid</tt>", "api_camera_provider.html#autotoc_md303", null ],
          [ "<tt>xr_camera_provider_is_valid_camera</tt>", "api_camera_provider.html#autotoc_md304", null ],
          [ "<tt>xr_camera_provider_create</tt>", "api_camera_provider.html#autotoc_md305", null ],
          [ "<tt>xr_camera_provider_start</tt>", "api_camera_provider.html#autotoc_md306", null ],
          [ "<tt>xr_camera_provider_stop</tt>", "api_camera_provider.html#autotoc_md307", null ],
          [ "<tt>xr_camera_provider_destroy</tt>", "api_camera_provider.html#autotoc_md308", null ],
          [ "<tt>xr_camera_provider_is_streaming</tt>", "api_camera_provider.html#autotoc_md309", null ]
        ] ],
        [ "Usage Example", "api_camera_provider.html#autotoc_md310", null ]
      ] ],
      [ "viture_stat_reporter.h", "api_stat_reporter.html", [
        [ "Overview", "api_stat_reporter.html#autotoc_md311", null ],
        [ "Network Endpoint", "api_stat_reporter.html#autotoc_md312", null ],
        [ "Functions", "api_stat_reporter.html#autotoc_md313", [
          [ "<tt>xr_stat_reporter_init</tt>", "api_stat_reporter.html#autotoc_md314", null ],
          [ "<tt>xr_stat_reporter_glasses_bind</tt>", "api_stat_reporter.html#autotoc_md315", null ]
        ] ],
        [ "Threading", "api_stat_reporter.html#autotoc_md316", null ],
        [ "Usage Example", "api_stat_reporter.html#autotoc_md317", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"api_camera_provider.html",
"page_quickstart.html#autotoc_md81"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
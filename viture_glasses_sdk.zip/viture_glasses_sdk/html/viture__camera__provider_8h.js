var viture__camera__provider_8h =
[
    [ "XRCameraFrame", "structXRCameraFrame.html", null ],
    [ "XRCameraFrameCallback", "viture__camera__provider_8h.html#a8e7135bc4a4ca437531f3903b09ee80e", null ],
    [ "XRCameraProviderHandle", "viture__camera__provider_8h.html#a3854e5d42749e32021c40e556cde1c0a", null ],
    [ "XRCameraFormat", "viture__camera__provider_8h.html#ad30b9093b7b3847ca3bab2b83a8e3845", [
      [ "XR_CAMERA_FORMAT_MJPEG", "viture__camera__provider_8h.html#ad30b9093b7b3847ca3bab2b83a8e3845aa2d33e255388e5955fb238834169cacb", null ]
    ] ],
    [ "xr_camera_provider_create", "viture__camera__provider_8h.html#a4b15734a93d181b647c3fccf463c934a", null ],
    [ "xr_camera_provider_destroy", "viture__camera__provider_8h.html#a19c9ad000a70589ac67d9fba4a314c56", null ],
    [ "xr_camera_provider_get_camera_pid", "viture__camera__provider_8h.html#a61dab7495e38c3234c50e07bd4f35528", null ],
    [ "xr_camera_provider_get_camera_vid", "viture__camera__provider_8h.html#a3075069987016457e93e071ebf9760ad", null ],
    [ "xr_camera_provider_is_streaming", "viture__camera__provider_8h.html#ab9e90a0c4e15e1b155726ae88f265af7", null ],
    [ "xr_camera_provider_is_valid_camera", "viture__camera__provider_8h.html#ac454fdc2ad109aace6aa61d476f5a1c4", null ],
    [ "xr_camera_provider_start", "viture__camera__provider_8h.html#a0856de7fa7c507e64a4c0e7d7a4d9aa3", null ],
    [ "xr_camera_provider_stop", "viture__camera__provider_8h.html#a2d548055c8bd770f8cd5f1c1b30e5837", null ]
];
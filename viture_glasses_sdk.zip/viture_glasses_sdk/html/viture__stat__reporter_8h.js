var viture__stat__reporter_8h =
[
    [ "xr_stat_reporter_glasses_bind", "viture__stat__reporter_8h.html#adb2da04ac93d5a41419e6e32bb830f94", null ],
    [ "xr_stat_reporter_init", "viture__stat__reporter_8h.html#a4277647fe77c3691774a33c9fe97810d", null ]
];
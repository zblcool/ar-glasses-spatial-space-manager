var viture__result_8h =
[
    [ "VITURE_GLASSES_ERROR_CALIB_INIT", "viture__result_8h.html#aba577a1a1b6d53cbff0499929688cf02", null ],
    [ "VITURE_GLASSES_ERROR_DATA_PARSE", "viture__result_8h.html#aa03d257b18ead46dba9ef3deaba073c9", null ],
    [ "VITURE_GLASSES_ERROR_DEVICE_REJECTED", "viture__result_8h.html#a31155a9fb7d2bd140efc10988b415550", null ],
    [ "VITURE_GLASSES_ERROR_HANDLE_DESTROYED", "viture__result_8h.html#a422ef15f9e162289ae8cba9cb6933828", null ],
    [ "VITURE_GLASSES_ERROR_INVALID_PARAM", "viture__result_8h.html#ac915d8c7e0d6e21b817ddf8624d5c34a", null ],
    [ "VITURE_GLASSES_ERROR_INVALID_STATE", "viture__result_8h.html#a2b3d66e6fc173f4fcb274fcf94f7279e", null ],
    [ "VITURE_GLASSES_ERROR_NO_DATA", "viture__result_8h.html#ad0ac6958a5a41b747f22ecc7de15aab4", null ],
    [ "VITURE_GLASSES_ERROR_NOT_SUPPORTED", "viture__result_8h.html#acd0f472d7ab4bf001980b530315aa9ec", null ],
    [ "VITURE_GLASSES_ERROR_SERIAL_FETCH", "viture__result_8h.html#a8acc5cab91486b53cfdb68e03bf43340", null ],
    [ "VITURE_GLASSES_ERROR_UNKNOWN", "viture__result_8h.html#a66d307f83a68286466f843d2b6aba776", null ],
    [ "VITURE_GLASSES_ERROR_USB_EXEC", "viture__result_8h.html#acd8f331d3a44fc989f9b525dc4a2a305", null ],
    [ "VITURE_GLASSES_ERROR_USB_UNAVAILABLE", "viture__result_8h.html#a296a265ccd4a95778dff60203ede6c18", null ],
    [ "VITURE_GLASSES_SUCCESS", "viture__result_8h.html#ad847120fe887e9ace132ea661f6ccc26", null ]
];
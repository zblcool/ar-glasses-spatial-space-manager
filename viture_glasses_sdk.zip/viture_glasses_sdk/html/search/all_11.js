var searchData=
[
  ['h_0',['h',['../api_camera_provider.html',1,'viture_camera_provider.h'],['../api_device.html',1,'viture_device.h'],['../api_device_carina.html',1,'viture_device_carina.h'],['../api_glasses_provider.html',1,'viture_glasses_provider.h'],['../api_macros_public.html',1,'viture_macros_public.h'],['../api_protocol_public.html',1,'viture_protocol_public.h'],['../api_stat_reporter.html',1,'viture_stat_reporter.h']]],
  ['handle_3a_20xrdeviceproviderhandle_1',['The Handle: XRDeviceProviderHandle',['../page_concepts.html#autotoc_md43',1,'']]],
  ['handling_2',['Error Handling',['../page_concepts.html#autotoc_md57',1,'']]],
  ['hardware_3',['Supported Hardware',['../page_overview.html#autotoc_md30',1,'']]],
  ['hardware_20button_20lock_4',['Hardware Button Lock',['../page_device_control.html#autotoc_md125',1,'']]],
  ['head_20tracking_5',['Head Tracking',['../page_head_tracking.html',1,'page_overview']]],
  ['headers_20at_20a_20glance_6',['Headers at a Glance',['../page_overview.html#autotoc_md38',1,'']]],
  ['height_7',['height',['../structXRCameraFrame.html#a3f1926afbc776f6eca57f510b4055635',1,'XRCameraFrame']]],
  ['how_20android_20differs_20from_20desktop_8',['How Android Differs from Desktop',['../page_android.html#autotoc_md166',1,'']]]
];

var searchData=
[
  ['—_206dof_20pose_20polling_0',['Carina (Luma Ultra) — 6DoF Pose Polling',['../page_head_tracking.html#autotoc_md96',1,'']]],
  ['—_20callback_20model_1',['Gen1 / Gen2 — Callback Model',['../page_concepts.html#autotoc_md50',1,'']]],
  ['—_20check_20device_20type_2',['Step 3 — Check Device Type',['../page_quickstart.html#autotoc_md71',1,'']]],
  ['—_20cleanup_3',['Step 7 — Cleanup',['../page_quickstart.html#autotoc_md79',1,'']]],
  ['—_20create_20the_20camera_20provider_4',['Step 2 — Create the Camera Provider',['../page_camera.html#autotoc_md153',1,'']]],
  ['—_20create_20the_20provider_5',['Step 2 — Create the Provider',['../page_quickstart.html#autotoc_md69',1,'']]],
  ['—_20decoding_20mjpeg_6',['Step 4 — Decoding MJPEG',['../page_camera.html#autotoc_md155',1,'']]],
  ['—_20desktop_20c_7',['Quick Start — Desktop (C++)',['../page_quickstart.html',1,'page_overview']]],
  ['—_20discover_20the_20camera_20vid_20pid_8',['Step 1 — Discover the Camera VID/PID',['../page_camera.html#autotoc_md152',1,'']]],
  ['—_20enable_20imu_20or_20start_20pose_20polling_9',['Step 6 — Enable IMU or Start Pose Polling',['../page_quickstart.html#autotoc_md77',1,'']]],
  ['—_20find_20a_20connected_20device_10',['Step 1 — Find a Connected Device',['../page_quickstart.html#autotoc_md66',1,'']]],
  ['—_20imu_20callbacks_11',['Gen1 / Gen2 — IMU Callbacks',['../page_head_tracking.html#autotoc_md87',1,'']]],
  ['—_20initialize_20and_20start_12',['Step 5 — Initialize and Start',['../page_quickstart.html#autotoc_md75',1,'']]],
  ['—_20native_20mode_13',['Beast (Gen2) — Native Mode',['../page_device_control.html#autotoc_md135',1,'']]],
  ['—_20polling_20model_14',['Carina — Polling Model',['../page_concepts.html#autotoc_md51',1,'']]],
  ['—_20register_20callbacks_20gen1_20gen2_20only_15',['Step 4 — Register Callbacks (Gen1 / Gen2 only)',['../page_quickstart.html#autotoc_md73',1,'']]],
  ['—_20start_20streaming_16',['Step 3 — Start Streaming',['../page_camera.html#autotoc_md154',1,'']]],
  ['—_20stop_20and_20destroy_17',['Step 5 — Stop and Destroy',['../page_camera.html#autotoc_md156',1,'']]],
  ['—_20switching_20back_20to_20native_20mode_18',['Beast — Switching Back to Native Mode',['../page_device_control.html#autotoc_md147',1,'']]],
  ['—_20switching_20to_20bypass_20mode_19',['Beast — Switching to Bypass Mode',['../page_device_control.html#autotoc_md146',1,'']]]
];

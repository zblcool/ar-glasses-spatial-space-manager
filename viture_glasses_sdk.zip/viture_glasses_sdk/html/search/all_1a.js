var searchData=
[
  ['querying_20value_20limits_0',['Querying Value Limits',['../page_device_control.html#autotoc_md118',1,'']]],
  ['quick_20reference_1',['Quick Reference',['../page_native_dof_devices.html#autotoc_md203',1,'']]],
  ['quick_20start_20—_20desktop_20c_2',['Quick Start — Desktop (C++)',['../page_quickstart.html',1,'page_overview']]]
];

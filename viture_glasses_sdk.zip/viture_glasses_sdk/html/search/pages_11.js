var searchData=
[
  ['v2_201_200_0',['v2.1.0',['../release_v210.html',1,'release_notes']]],
  ['v2_201_201_1',['v2.1.1',['../release_v211.html',1,'release_notes']]],
  ['v2_201_202_2',['v2.1.2',['../release_v212.html',1,'release_notes']]],
  ['v2_202_200_3',['v2.2.0',['../release_v220.html',1,'release_notes']]],
  ['v2_202_201_4',['v2.2.1',['../release_v221.html',1,'release_notes']]],
  ['v2_203_200_5',['v2.3.0',['../release_v230.html',1,'release_notes']]],
  ['v2_203_201_6',['v2.3.1',['../release_v231.html',1,'release_notes']]],
  ['v2_203_202_7',['v2.3.2',['../release_v232.html',1,'release_notes']]],
  ['v2_204_200_8',['v2.4.0',['../release_v240.html',1,'release_notes']]],
  ['v2_204_201_9',['v2.4.1',['../release_v241.html',1,'release_notes']]],
  ['viture_20glasses_20sdk_20documentation_10',['VITURE Glasses SDK Documentation',['../page_overview.html',1,'']]],
  ['viture_5fcamera_5fprovider_20h_11',['viture_camera_provider.h',['../api_camera_provider.html',1,'page_api_reference']]],
  ['viture_5fdevice_20h_12',['viture_device.h',['../api_device.html',1,'page_api_reference']]],
  ['viture_5fdevice_5fcarina_20h_13',['viture_device_carina.h',['../api_device_carina.html',1,'page_api_reference']]],
  ['viture_5fglasses_5fprovider_20h_14',['viture_glasses_provider.h',['../api_glasses_provider.html',1,'page_api_reference']]],
  ['viture_5fmacros_5fpublic_20h_15',['viture_macros_public.h',['../api_macros_public.html',1,'page_api_reference']]],
  ['viture_5fprotocol_5fpublic_20h_16',['viture_protocol_public.h',['../api_protocol_public.html',1,'page_api_reference']]],
  ['viture_5fstat_5freporter_20h_17',['viture_stat_reporter.h',['../api_stat_reporter.html',1,'page_api_reference']]]
];

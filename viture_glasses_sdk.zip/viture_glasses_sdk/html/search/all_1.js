var searchData=
[
  ['1_0',['1',['../release_v221.html',1,'v2.2.1'],['../release_v231.html',1,'v2.3.1'],['../release_v241.html',1,'v2.4.1']]],
  ['1_20—_20discover_20the_20camera_20vid_20pid_1',['Step 1 — Discover the Camera VID/PID',['../page_camera.html#autotoc_md152',1,'']]],
  ['1_20—_20find_20a_20connected_20device_2',['Step 1 — Find a Connected Device',['../page_quickstart.html#autotoc_md66',1,'']]],
  ['1_200_3',['v2.1.0',['../release_v210.html',1,'release_notes']]],
  ['1_201_4',['v2.1.1',['../release_v211.html',1,'release_notes']]],
  ['1_202_5',['v2.1.2',['../release_v212.html',1,'release_notes']]],
  ['10_5fv2_5f4_5f1_2emd_6',['10_v2_4_1.md',['../10__v2__4__1_8md.html',1,'']]],
  ['14_7',['Camera on Android (Android 14+)',['../page_android.html#autotoc_md179',1,'']]],
  ['1_5foverview_2emd_8',['1_overview.md',['../1__overview_8md.html',1,'']]],
  ['1_5fv2_5f1_5f0_2emd_9',['1_v2_1_0.md',['../1__v2__1__0_8md.html',1,'']]],
  ['1_5fviture_5fglasses_5fprovider_2emd_10',['1_viture_glasses_provider.md',['../1__viture__glasses__provider_8md.html',1,'']]]
];

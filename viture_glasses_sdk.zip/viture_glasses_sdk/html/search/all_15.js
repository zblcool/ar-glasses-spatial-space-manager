var searchData=
[
  ['level_20macros_0',['Log Level Macros',['../api_macros_public.html#autotoc_md228',1,'']]],
  ['lifecycle_1',['Lifecycle',['../page_stat_reporter.html#autotoc_md185',1,'']]],
  ['lifecycle_20states_2',['Lifecycle States',['../page_concepts.html#autotoc_md47',1,'']]],
  ['limitations_20on_20beast_3',['limitations on beast',['../release_v230.html#autotoc_md15',1,'Known Limitations on Beast'],['../release_v231.html#autotoc_md18',1,'Known Limitations on Beast']]],
  ['limits_4',['Querying Value Limits',['../page_device_control.html#autotoc_md118',1,'']]],
  ['linux_20udev_20rule_5',['Linux udev Rule',['../page_quickstart.html#autotoc_md62',1,'']]],
  ['lock_6',['Hardware Button Lock',['../page_device_control.html#autotoc_md125',1,'']]],
  ['log_20level_20macros_7',['Log Level Macros',['../api_macros_public.html#autotoc_md228',1,'']]],
  ['logging_8',['Logging',['../page_concepts.html#autotoc_md59',1,'']]],
  ['loghook_9',['LogHook',['../viture__glasses__provider_8h.html#ab20aa4cf7e7fd746db0747fa139abe5e',1,'viture_glasses_provider.h']]],
  ['loghook_20tt_10',['&lt;tt&gt;LogHook&lt;/tt&gt;',['../api_glasses_provider.html#autotoc_md207',1,'']]],
  ['logic_20flow_11',['Recommended Logic Flow',['../page_native_dof_devices.html#autotoc_md199',1,'']]],
  ['luma_20ultra_12',['Luma Ultra',['../page_quickstart.html#autotoc_md67',1,'']]],
  ['luma_20ultra_20—_206dof_20pose_20polling_13',['Carina (Luma Ultra) — 6DoF Pose Polling',['../page_head_tracking.html#autotoc_md96',1,'']]],
  ['luma_20ultra_20only_14',['Stereo Tracking Cameras (Carina / Luma Ultra only)',['../page_camera.html#autotoc_md160',1,'']]]
];

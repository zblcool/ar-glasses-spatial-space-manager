var searchData=
[
  ['a_20connected_20device_0',['Step 1 — Find a Connected Device',['../page_quickstart.html#autotoc_md66',1,'']]],
  ['a_20glance_1',['Headers at a Glance',['../page_overview.html#autotoc_md38',1,'']]],
  ['advanced_2',['Display Duty Cycle (Advanced)',['../page_device_control.html#autotoc_md142',1,'']]],
  ['and_206dof_20carina_3',['Switching Between 3DOF and 6DOF (Carina)',['../page_head_tracking.html#autotoc_md104',1,'']]],
  ['and_20destroy_4',['Step 5 — Stop and Destroy',['../page_camera.html#autotoc_md156',1,'']]],
  ['and_20distance_5',['Native Display Size and Distance',['../page_device_control.html#autotoc_md139',1,'']]],
  ['and_20resetting_6',['Recentering and Resetting',['../page_head_tracking.html#autotoc_md101',1,'']]],
  ['and_20start_7',['Step 5 — Initialize and Start',['../page_quickstart.html#autotoc_md75',1,'']]],
  ['android_8',['android',['../page_android.html#autotoc_md177',1,'Carina Pose Polling on Android'],['../page_android.html#autotoc_md175',1,'CMake Configuration for Android']]],
  ['android_20android_2014_9',['Camera on Android (Android 14+)',['../page_android.html#autotoc_md179',1,'']]],
  ['android_20differs_20from_20desktop_10',['How Android Differs from Desktop',['../page_android.html#autotoc_md166',1,'']]],
  ['android_20integration_20guide_11',['Android Integration Guide',['../page_android.html',1,'page_overview']]],
  ['androidmanifest_20xml_12',['AndroidManifest.xml',['../page_android.html#autotoc_md168',1,'']]],
  ['api_13',['VITURE api',['../api_macros_public.html#autotoc_md227',1,'']]],
  ['api_20changes_14',['API Changes',['../release_v231.html#autotoc_md17',1,'']]],
  ['api_20reference_15',['API Reference',['../page_api_reference.html',1,'']]],
  ['api_20should_20i_20use_16',['Which API Should I Use?',['../page_head_tracking.html#autotoc_md85',1,'']]],
  ['apis_17',['apis',['../release_v240.html#autotoc_md23',1,'New APIs'],['../release_v232.html#autotoc_md19',1,'New APIs'],['../release_v241.html#autotoc_md1',1,'New APIs']]],
  ['are_20em_20not_20em_20tied_20to_20native_20dof_18',['Things That Are &lt;em&gt;Not&lt;/em&gt; Tied to Native DOF',['../page_native_dof_devices.html#autotoc_md201',1,'']]],
  ['at_20a_20glance_19',['Headers at a Glance',['../page_overview.html#autotoc_md38',1,'']]]
];

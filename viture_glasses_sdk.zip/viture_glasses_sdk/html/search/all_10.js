var searchData=
[
  ['gen1_20gen2_20—_20callback_20model_0',['Gen1 / Gen2 — Callback Model',['../page_concepts.html#autotoc_md50',1,'']]],
  ['gen1_20gen2_20—_20imu_20callbacks_1',['Gen1 / Gen2 — IMU Callbacks',['../page_head_tracking.html#autotoc_md87',1,'']]],
  ['gen1_20gen2_20only_2',['Step 4 — Register Callbacks (Gen1 / Gen2 only)',['../page_quickstart.html#autotoc_md73',1,'']]],
  ['gen1_20gen2_20vs_20carina_3',['Summary: Gen1/Gen2 vs. Carina',['../page_head_tracking.html#autotoc_md106',1,'']]],
  ['gen2_20—_20callback_20model_4',['Gen1 / Gen2 — Callback Model',['../page_concepts.html#autotoc_md50',1,'']]],
  ['gen2_20—_20imu_20callbacks_5',['Gen1 / Gen2 — IMU Callbacks',['../page_head_tracking.html#autotoc_md87',1,'']]],
  ['gen2_20—_20native_20mode_6',['Beast (Gen2) — Native Mode',['../page_device_control.html#autotoc_md135',1,'']]],
  ['gen2_20only_7',['Step 4 — Register Callbacks (Gen1 / Gen2 only)',['../page_quickstart.html#autotoc_md73',1,'']]],
  ['gen2_20vs_20carina_8',['Summary: Gen1/Gen2 vs. Carina',['../page_head_tracking.html#autotoc_md106',1,'']]],
  ['general_20device_20setup_9',['General Device Setup',['../page_device_control.html#autotoc_md145',1,'']]],
  ['generation_10',['Behavior by Device Generation',['../page_device_control.html#autotoc_md128',1,'']]],
  ['glance_11',['Headers at a Glance',['../page_overview.html#autotoc_md38',1,'']]],
  ['glasses_20sdk_20documentation_12',['VITURE Glasses SDK Documentation',['../page_overview.html',1,'']]],
  ['glassstatecallback_13',['GlassStateCallback',['../viture__glasses__provider_8h.html#a2ea8b0f6cf78fed4b748b4abb93a4902',1,'viture_glasses_provider.h']]],
  ['glassstatecallback_20tt_14',['&lt;tt&gt;GlassStateCallback&lt;/tt&gt;',['../api_glasses_provider.html#autotoc_md206',1,'']]],
  ['guide_15',['guide',['../page_android.html',1,'Android Integration Guide'],['../page_overview.html#autotoc_md34',1,'Documentation Guide']]]
];

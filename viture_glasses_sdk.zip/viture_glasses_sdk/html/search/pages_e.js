var searchData=
[
  ['sdk_20documentation_0',['VITURE Glasses SDK Documentation',['../page_overview.html',1,'']]],
  ['sdk_20usage_20reporting_20stat_20reporter_1',['SDK Usage Reporting (Stat Reporter)',['../page_stat_reporter.html',1,'page_overview']]],
  ['start_20—_20desktop_20c_2',['Quick Start — Desktop (C++)',['../page_quickstart.html',1,'page_overview']]],
  ['stat_20reporter_3',['SDK Usage Reporting (Stat Reporter)',['../page_stat_reporter.html',1,'page_overview']]],
  ['streaming_4',['Camera Streaming',['../page_camera.html',1,'page_overview']]]
];

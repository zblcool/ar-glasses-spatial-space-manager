var searchData=
[
  ['—_20desktop_20c_0',['Quick Start — Desktop (C++)',['../page_quickstart.html',1,'page_overview']]]
];

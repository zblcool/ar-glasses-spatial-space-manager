var searchData=
[
  ['glasses_20sdk_20documentation_0',['VITURE Glasses SDK Documentation',['../page_overview.html',1,'']]],
  ['guide_1',['Android Integration Guide',['../page_android.html',1,'page_overview']]]
];

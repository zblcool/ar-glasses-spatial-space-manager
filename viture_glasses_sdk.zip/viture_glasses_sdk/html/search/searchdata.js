var indexSectionsWithContent =
{
  0: "0123456789abcdefghijklmnopqrstuvwx—",
  1: "x",
  2: "123456789iv",
  3: "x",
  4: "dfhstw",
  5: "glvx",
  6: "x",
  7: "x",
  8: "v",
  9: "01234acdghinqrstuv—"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};


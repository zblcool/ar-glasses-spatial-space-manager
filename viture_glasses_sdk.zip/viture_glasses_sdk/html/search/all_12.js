var searchData=
[
  ['i_20use_0',['Which API Should I Use?',['../page_head_tracking.html#autotoc_md85',1,'']]],
  ['identifiers_1',['identifiers',['../api_protocol_public.html#autotoc_md238',1,'Callback Identifiers'],['../api_protocol_public.html#autotoc_md232',1,'Display Mode Identifiers'],['../api_protocol_public.html#autotoc_md240',1,'Value Identifiers']]],
  ['identifiers_20for_20native_203dof_20devices_2',['Display Size Identifiers (for native 3DoF devices)',['../api_protocol_public.html#autotoc_md234',1,'']]],
  ['implementation_3',['Kotlin Implementation',['../page_android.html#autotoc_md171',1,'']]],
  ['imu_4',['imu',['../page_head_tracking.html#autotoc_md92',1,'Disabling the IMU'],['../page_head_tracking.html#autotoc_md91',1,'Enabling the IMU']]],
  ['imu_20callbacks_5',['Gen1 / Gen2 — IMU Callbacks',['../page_head_tracking.html#autotoc_md87',1,'']]],
  ['imu_20configuration_6',['IMU Configuration',['../api_protocol_public.html#autotoc_md237',1,'']]],
  ['imu_20or_20start_20pose_20polling_7',['Step 6 — Enable IMU or Start Pose Polling',['../page_quickstart.html#autotoc_md77',1,'']]],
  ['index_2emd_8',['index.md',['../0__release__notes_2index_8md.html',1,'(Global Namespace)'],['../2__api__documents_2index_8md.html',1,'(Global Namespace)']]],
  ['initialize_20and_20start_9',['Step 5 — Initialize and Start',['../page_quickstart.html#autotoc_md75',1,'']]],
  ['integration_20guide_10',['Android Integration Guide',['../page_android.html',1,'page_overview']]]
];

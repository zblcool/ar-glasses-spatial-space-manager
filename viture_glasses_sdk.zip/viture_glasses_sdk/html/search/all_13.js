var searchData=
[
  ['jni_20bridge_20pattern_0',['JNI Bridge Pattern',['../page_android.html#autotoc_md173',1,'']]]
];

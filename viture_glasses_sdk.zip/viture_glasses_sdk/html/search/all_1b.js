var searchData=
[
  ['ranges_0',['ranges',['../api_protocol_public.html#autotoc_md239',1,'Callback Value Ranges'],['../page_device_control.html#autotoc_md115',1,'Value Ranges'],['../page_device_control.html#ValueRanges',1,'Value Ranges']]],
  ['rate_1',['Polling Rate',['../page_head_tracking.html#autotoc_md100',1,'']]],
  ['raw_20callback_2',['Raw Callback',['../page_head_tracking.html#autotoc_md90',1,'']]],
  ['read_3',['read',['../page_device_control.html#autotoc_md132',1,'Read'],['../page_device_control.html#autotoc_md111',1,'Read']]],
  ['read_20write_4',['read write',['../page_device_control.html#autotoc_md129',1,'Read / Write'],['../page_device_control.html#autotoc_md122',1,'Read / Write'],['../page_device_control.html#autotoc_md116',1,'Read / Write']]],
  ['recentering_20and_20resetting_5',['Recentering and Resetting',['../page_head_tracking.html#autotoc_md101',1,'']]],
  ['recommended_20logic_20flow_6',['Recommended Logic Flow',['../page_native_dof_devices.html#autotoc_md199',1,'']]],
  ['reference_7',['reference',['../page_api_reference.html',1,'API Reference'],['../page_native_dof_devices.html#autotoc_md203',1,'Quick Reference']]],
  ['register_20callbacks_20gen1_20gen2_20only_8',['Step 4 — Register Callbacks (Gen1 / Gen2 only)',['../page_quickstart.html#autotoc_md73',1,'']]],
  ['registering_20the_20stereo_20callback_9',['Registering the Stereo Callback',['../page_camera.html#autotoc_md161',1,'']]],
  ['release_20notes_10',['Release Notes',['../release_notes.html',1,'']]],
  ['render_20thread_11',['Sharing Pose Data with the Render Thread',['../page_head_tracking.html#autotoc_md93',1,'']]],
  ['reporter_12',['SDK Usage Reporting (Stat Reporter)',['../page_stat_reporter.html',1,'page_overview']]],
  ['reporting_20stat_20reporter_13',['SDK Usage Reporting (Stat Reporter)',['../page_stat_reporter.html',1,'page_overview']]],
  ['required_20call_20order_14',['Required Call Order',['../api_glasses_provider.html#autotoc_md209',1,'']]],
  ['resetting_15',['Recentering and Resetting',['../page_head_tracking.html#autotoc_md101',1,'']]],
  ['result_20codes_16',['Result Codes',['../api_protocol_public.html#autotoc_md231',1,'']]],
  ['return_20codes_17',['Return Codes',['../page_stat_reporter.html#autotoc_md189',1,'']]],
  ['right_20camera_18',['Choosing the Right Camera',['../page_camera.html#autotoc_md164',1,'']]],
  ['rule_19',['Linux udev Rule',['../page_quickstart.html#autotoc_md62',1,'']]]
];

var searchData=
[
  ['families_0',['Device Families',['../page_concepts.html#autotoc_md45',1,'']]],
  ['features_1',['features',['../release_v210.html#autotoc_md5',1,'New Features'],['../release_v220.html#autotoc_md8',1,'New Features'],['../release_v221.html#autotoc_md10',1,'New Features'],['../release_v230.html#autotoc_md13',1,'New Features'],['../release_v240.html#autotoc_md25',1,'New Features']]],
  ['film_2',['Electrochromic Film',['../page_device_control.html#autotoc_md127',1,'']]],
  ['find_20a_20connected_20device_3',['Step 1 — Find a Connected Device',['../page_quickstart.html#autotoc_md66',1,'']]],
  ['five_20minute_20overview_4',['Five-Minute Overview',['../page_overview.html#autotoc_md36',1,'']]],
  ['fixes_5',['fixes',['../release_v241.html#autotoc_md3',1,'Bug Fixes'],['../release_v240.html#autotoc_md26',1,'Bug Fixes'],['../release_v231.html#autotoc_md16',1,'Bug Fixes'],['../release_v230.html#autotoc_md14',1,'Bug Fixes'],['../release_v221.html#autotoc_md11',1,'Bug Fixes'],['../release_v220.html#autotoc_md9',1,'Bug Fixes'],['../release_v232.html#autotoc_md20',1,'Bug Fixes']]],
  ['flow_6',['flow',['../page_native_dof_devices.html#autotoc_md199',1,'Recommended Logic Flow'],['../page_android.html#autotoc_md170',1,'USB Permission Flow']]],
  ['for_20android_7',['CMake Configuration for Android',['../page_android.html#autotoc_md175',1,'']]],
  ['for_20native_203dof_20devices_8',['for native 3dof devices',['../api_protocol_public.html#autotoc_md234',1,'Display Size Identifiers (for native 3DoF devices)'],['../api_protocol_public.html#autotoc_md235',1,'Native DOF Modes (for native 3DoF devices)']]],
  ['for_20native_20mode_20currently_20beast_20only_9',['Display Modes for Native Mode (currently Beast only)',['../api_protocol_public.html#autotoc_md236',1,'']]],
  ['format_10',['format',['../structXRCameraFrame.html#aa843ee205dad6656949097f86134ac94',1,'XRCameraFrame']]],
  ['from_20desktop_11',['How Android Differs from Desktop',['../page_android.html#autotoc_md166',1,'']]],
  ['full_20sequence_20diagram_12',['Full Sequence Diagram',['../page_android.html#autotoc_md181',1,'']]],
  ['functions_13',['functions',['../api_glasses_provider.html#autotoc_md210',1,'Functions'],['../api_protocol_public.html#autotoc_md241',1,'Functions'],['../api_device.html#autotoc_md276',1,'Functions'],['../api_device_carina.html#autotoc_md286',1,'Functions'],['../api_camera_provider.html#autotoc_md301',1,'Functions'],['../api_stat_reporter.html#autotoc_md313',1,'Functions']]]
];

var searchData=
[
  ['on_20android_0',['Carina Pose Polling on Android',['../page_android.html#autotoc_md177',1,'']]],
  ['on_20android_20android_2014_1',['Camera on Android (Android 14+)',['../page_android.html#autotoc_md179',1,'']]],
  ['on_20beast_2',['on beast',['../release_v230.html#autotoc_md15',1,'Known Limitations on Beast'],['../release_v231.html#autotoc_md18',1,'Known Limitations on Beast']]],
  ['on_20mode_3',['Default Power-On Mode',['../page_device_control.html#autotoc_md124',1,'']]],
  ['only_4',['only',['../api_protocol_public.html#autotoc_md236',1,'Display Modes for Native Mode (currently Beast only)'],['../page_quickstart.html#autotoc_md73',1,'Step 4 — Register Callbacks (Gen1 / Gen2 only)'],['../page_camera.html#autotoc_md160',1,'Stereo Tracking Cameras (Carina / Luma Ultra only)']]],
  ['opengl_5',['Coordinate Conversion: NWU to OpenGL',['../page_head_tracking.html#autotoc_md94',1,'']]],
  ['optional_20callbacks_6',['Carina Optional Callbacks',['../page_head_tracking.html#autotoc_md102',1,'']]],
  ['or_20start_20pose_20polling_7',['Step 6 — Enable IMU or Start Pose Polling',['../page_quickstart.html#autotoc_md77',1,'']]],
  ['order_8',['Required Call Order',['../api_glasses_provider.html#autotoc_md209',1,'']]],
  ['overview_9',['overview',['../page_camera.html#autotoc_md149',1,'Camera Overview'],['../page_overview.html#autotoc_md36',1,'Five-Minute Overview'],['../api_camera_provider.html#autotoc_md294',1,'Overview'],['../api_stat_reporter.html#autotoc_md311',1,'Overview']]]
];

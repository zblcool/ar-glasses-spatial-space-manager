var searchData=
[
  ['2_0',['2',['../release_v212.html',1,'v2.1.2'],['../release_v232.html',1,'v2.3.2']]],
  ['2_20—_20create_20the_20camera_20provider_1',['Step 2 — Create the Camera Provider',['../page_camera.html#autotoc_md153',1,'']]],
  ['2_20—_20create_20the_20provider_2',['Step 2 — Create the Provider',['../page_quickstart.html#autotoc_md69',1,'']]],
  ['2_200_3',['v2.2.0',['../release_v220.html',1,'release_notes']]],
  ['2_201_4',['v2.2.1',['../release_v221.html',1,'release_notes']]],
  ['2_5fconcepts_2emd_5',['2_concepts.md',['../2__concepts_8md.html',1,'']]],
  ['2_5fv2_5f1_5f1_2emd_6',['2_v2_1_1.md',['../2__v2__1__1_8md.html',1,'']]],
  ['2_5fviture_5fmacros_5fpublic_2emd_7',['2_viture_macros_public.md',['../2__viture__macros__public_8md.html',1,'']]],
  ['2d_203d_20toggle_8',['2d 3d toggle',['../page_device_control.html#autotoc_md123',1,'Convenience: 2D / 3D Toggle'],['../page_device_control.html#autotoc_md140',1,'Native 2D / 3D Toggle']]]
];

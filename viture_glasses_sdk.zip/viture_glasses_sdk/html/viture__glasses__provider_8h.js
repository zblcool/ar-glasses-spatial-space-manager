var viture__glasses__provider_8h =
[
    [ "GlassStateCallback", "viture__glasses__provider_8h.html#a2ea8b0f6cf78fed4b748b4abb93a4902", null ],
    [ "LogHook", "viture__glasses__provider_8h.html#ab20aa4cf7e7fd746db0747fa139abe5e", null ],
    [ "XRDeviceProviderHandle", "viture__glasses__provider_8h.html#a673cef8049a5e15343c066644d99fb8c", null ],
    [ "XRDeviceType", "viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3e", [
      [ "XR_DEVICE_TYPE_VITURE_GEN1", "viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea0551526d67deed27f08de249e886ae09", null ],
      [ "XR_DEVICE_TYPE_VITURE_GEN2", "viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea0e4ccea9e04cf2c1af3f0948dd074c2d", null ],
      [ "XR_DEVICE_TYPE_VITURE_CARINA", "viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea1231a632c9a7b53c9b1d384d57ae2590", null ]
    ] ],
    [ "xr_device_provider_create", "viture__glasses__provider_8h.html#ac1cbb3910e652f2643724e02a2606819", null ],
    [ "xr_device_provider_destroy", "viture__glasses__provider_8h.html#a04fb5a26c683ca45c90d634f8739be78", null ],
    [ "xr_device_provider_get_device_type", "viture__glasses__provider_8h.html#a31b9d15ed41212e5c6c4077cf1088018", null ],
    [ "xr_device_provider_get_log_level", "viture__glasses__provider_8h.html#ad1cf89c969f6eb7ec25a130f892d5942", null ],
    [ "xr_device_provider_get_market_name", "viture__glasses__provider_8h.html#a294544b1523b6ed49067c4dbb97c5245", null ],
    [ "xr_device_provider_get_thread_id", "viture__glasses__provider_8h.html#aaf07024a767526c5422ada7319a29199", null ],
    [ "xr_device_provider_initialize", "viture__glasses__provider_8h.html#aaa1bbfd35873052bbbf529cb816f3934", null ],
    [ "xr_device_provider_is_product_id_valid", "viture__glasses__provider_8h.html#a8f98359a2fb11cd2d612baa6edaeb7bb", null ],
    [ "xr_device_provider_is_product_support_imu_frequency", "viture__glasses__provider_8h.html#a5fd478ad9128e31aef5a70cbaef2fcc3", null ],
    [ "xr_device_provider_is_product_support_native_dof", "viture__glasses__provider_8h.html#afa2b68e09fc87924311ae66302446340", null ],
    [ "xr_device_provider_register_state_callback", "viture__glasses__provider_8h.html#a76acc782249e68d54ee99f5dbfc7fe5b", null ],
    [ "xr_device_provider_set_log_hook", "viture__glasses__provider_8h.html#a61ec4adc0db3937919c1ea4e59670202", null ],
    [ "xr_device_provider_set_log_level", "viture__glasses__provider_8h.html#a94b6e87a2296e8d648ed5de2e6f419af", null ],
    [ "xr_device_provider_shutdown", "viture__glasses__provider_8h.html#a1586b3cd1bec406566e6651ad56f4828", null ],
    [ "xr_device_provider_start", "viture__glasses__provider_8h.html#a1409b6f85be2873df9c5f901c9922614", null ],
    [ "xr_device_provider_stop", "viture__glasses__provider_8h.html#a863b231e3a6d91c278d290aff397d17f", null ]
];
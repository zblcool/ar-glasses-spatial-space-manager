// Copyright (C) 2026 Viture Inc. All rights reserved.

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "device_enum.h"
#include "raylib.h"
#include "viture_device.h"
#include "viture_device_carina.h"
#include "viture_glasses_provider.h"
#include "viture_protocol_public.h"

#include "camera_bg.h"
#include "carina_camera.h"
#include "hud.h"
#include "imu_state.h"
#include "scene_3dof.h"
#include "scene_6dof.h"

// ---- globals ----------------------------------------------------------------

static std::atomic<bool>      g_running{true};
static XRDeviceProviderHandle g_handle          = nullptr;
static int                    g_selected_pid    = -1;
static char                   g_market_name[64] = "No device";
static char                   g_sn_hash[65]     = "";  // hex SHA-256 of the board SN; empty = unknown
static int                    g_device_type     = -1;
static bool                   g_sdk_started     = false;  // true after xr_device_provider_start

// Shared IMU/pose state (written by SDK callback / poll thread, read by render thread)
static PoseState g_imu;

// Yaw offset for 3DOF recentering (Gen1/Gen2 and Carina 3DOF)
static float  g_yaw_offset       = 0.0f;
static bool   g_yaw_init_done    = false;

// Carina pose poll thread
static std::atomic<bool> g_poll_running{false};
static std::thread       g_poll_thread;

// Whether Carina is currently running in 6DOF mode (false = 3DOF)
static bool g_carina_6dof = false;

// Carina camera exposure control (false = automatic exposure).
static bool  g_carina_exp_manual  = false;
static float g_carina_exp_time_ms = 4.0f;   // [0.01, 8.0]
static int   g_carina_exp_gain    = 4;      // [0, 15]

// Native-DOF (Beast) 3DOF source: true = on-device (native mode, glasses track
// and reproject a fixed-camera scene), false = on-host (bypass mode, host
// renders 3DOF from pose data like a regular Gen2). Default on-device.
static bool g_native_on_device = true;

// Carina 6DOF software pose reference for full-axis recenter (R key).
// Pitch and roll are gravity-anchored in the Carina VIO system and cannot be
// reset via xr_device_provider_reset_origin_carina, so the camera is driven by
// the pose relative to this stored reference instead of the raw absolute pose.
static float g_carina_quat_ref[4] = {1.0f, 0.0f, 0.0f, 0.0f};
static float g_carina_pos_ref[3]  = {};
static bool  g_carina_ref_init    = false;

// App state machine
enum class AppState {
    SCANNING,          // no device found; [R] to rescan
    SELECTING_DEV,     // multiple devices found; pick one in-window
    CARINA_SELECTING,  // Carina connected; pick 3DOF or 6DOF
    NATIVE_SELECTING,  // Beast connected; pick on-device or on-host 3DOF
    TRACKING,          // normal tracking
    DISCONNECTED,      // device lost mid-run; [R] to rescan
};
static AppState      g_app_state  = AppState::SCANNING;
static std::vector<int> g_found_pids;  // PIDs from the most recent scan

// Persistent device state updated by StateCallback (-1 = not yet received)
static std::mutex g_dev_state_mtx;
static int g_brightness = -1;
static int g_volume     = -1;
static int g_film       = -1;

// ---- signal handling --------------------------------------------------------

static void signal_handler(int) { g_running = false; }

// ---- SDK callbacks ----------------------------------------------------------

static void StateCallback(int glass_state_id, int glass_value)
{
    printf("[state] id=%d value=%d\n", glass_state_id, glass_value);
    fflush(stdout);

    std::lock_guard<std::mutex> lk(g_dev_state_mtx);
    switch (glass_state_id) {
        case VITURE_CALLBACK_ID_BRIGHTNESS:          g_brightness = glass_value; break;
        case VITURE_CALLBACK_ID_VOLUME:              g_volume     = glass_value; break;
        case VITURE_CALLBACK_ID_ELECTROCHROMIC_FILM: g_film       = glass_value; break;
        default: break;
    }
}

// Invoked on the SDK IMU thread for Gen1/Gen2 devices.
// data: [roll, pitch, yaw, quat_w, quat_x, quat_y, quat_z]  NWU frame
static void PoseCallback(float* data, uint64_t /*timestamp*/)
{
    std::lock_guard<std::mutex> lk(g_imu.mtx);
    g_imu.euler[0] = data[0];
    g_imu.euler[1] = data[1];
    g_imu.euler[2] = data[2];
    g_imu.quat[0]  = data[3];
    g_imu.quat[1]  = data[4];
    g_imu.quat[2]  = data[5];
    g_imu.quat[3]  = data[6];
    g_imu.fresh    = true;
}

// Carina pose polling thread (~120 Hz)
// pose[7]: [px, py, pz, qw, qx, qy, qz] in OpenGL convention (Y-up, right-handed)
static void carina_poll_fn()
{
    float pose[7] = {};
    while (g_poll_running) {
        int status = 1;  // default to unstable
        if (xr_device_provider_get_gl_pose_carina(g_handle, pose, 0.0, &status)
                == VITURE_GLASSES_SUCCESS) {
            std::lock_guard<std::mutex> lk(g_imu.mtx);
            g_imu.pos[0]         = pose[0];
            g_imu.pos[1]         = pose[1];
            g_imu.pos[2]         = pose[2];
            g_imu.carina_quat[0] = pose[3];  // w
            g_imu.carina_quat[1] = pose[4];  // x
            g_imu.carina_quat[2] = pose[5];  // y
            g_imu.carina_quat[3] = pose[6];  // z
            g_imu.pose_status    = status;
            g_imu.fresh          = true;
        }
        std::this_thread::sleep_for(std::chrono::microseconds(8333));  // ~120 Hz
    }
}

// ---- SDK lifecycle helpers --------------------------------------------------

// Read brightness / volume / film / SN hash from the device and store in globals.
// Must be called after xr_device_provider_start.
static void read_initial_device_state()
{
    uint8_t hash[32];
    if (xr_device_provider_get_sn_hash(g_handle, hash) == VITURE_GLASSES_SUCCESS) {
        for (int i = 0; i < 32; ++i)
            snprintf(g_sn_hash + i * 2, 3, "%02x", hash[i]);
    }

    int bri = xr_device_provider_get_brightness_level(g_handle);
    int vol = xr_device_provider_get_volume_level(g_handle);
    float film_v = 0.0f;
    int film_err = xr_device_provider_get_film_mode(g_handle, &film_v);
    std::lock_guard<std::mutex> lk(g_dev_state_mtx);
    if (bri >= 0) g_brightness = bri;
    if (vol >= 0) g_volume     = vol;
    if (film_err == VITURE_GLASSES_SUCCESS)
        g_film = static_cast<int>(film_v + 0.5f);
}

// Reset shared IMU state and device state to "no data" values.
static void reset_state()
{
    {
        std::lock_guard<std::mutex> lk(g_imu.mtx);
        g_imu.fresh       = false;
        g_imu.pose_status = 1;
        memset(g_imu.euler,       0, sizeof(g_imu.euler));
        memset(g_imu.quat,        0, sizeof(g_imu.quat));
        memset(g_imu.pos,         0, sizeof(g_imu.pos));
        memset(g_imu.carina_quat, 0, sizeof(g_imu.carina_quat));
    }
    {
        std::lock_guard<std::mutex> lk(g_dev_state_mtx);
        g_brightness = g_volume = g_film = -1;
    }
    g_sn_hash[0]        = '\0';
    g_yaw_offset        = 0.0f;
    g_yaw_init_done     = false;
    g_carina_quat_ref[0] = 1.0f;
    g_carina_quat_ref[1] = g_carina_quat_ref[2] = g_carina_quat_ref[3] = 0.0f;
    memset(g_carina_pos_ref, 0, sizeof(g_carina_pos_ref));
    g_carina_ref_init = false;
}

// Full teardown: stops threads, destroys SDK handle, clears all device globals.
// Safe to call even if SDK was only partially initialized.
static void full_teardown()
{
    camera_bg_stop();
    carina_camera_set(false);

    if (g_poll_running) {
        g_poll_running = false;
        if (g_poll_thread.joinable()) g_poll_thread.join();
    }
    if (g_handle) {
        if (g_sdk_started && is_gen1_or_gen2(g_device_type) &&
            !(supports_native_dof(g_selected_pid) && g_native_on_device)) {
            xr_device_provider_close_imu(g_handle, VITURE_IMU_MODE_POSE);
        }
        if (g_sdk_started) {
            xr_device_provider_stop(g_handle);
            xr_device_provider_shutdown(g_handle);
        }
        xr_device_provider_destroy(g_handle);
        g_handle = nullptr;
    }
    g_sdk_started  = false;
    g_selected_pid = -1;
    g_device_type  = -1;
    g_carina_6dof  = false;
    g_native_on_device = true;
    snprintf(g_market_name, sizeof(g_market_name), "No device");
    reset_state();
}

// Register the pose callback and open the IMU at the highest supported pose
// frequency. Shared by regular Gen1/Gen2 and Beast on-host (bypass) 3DOF.
static void start_host_pose_tracking(int pid)
{
    xr_device_provider_register_imu_pose_callback(g_handle, PoseCallback);
    // Pose-mode frequency support varies by model (e.g. Pro 2 caps pose at
    // 120Hz). Pick the highest supported rate instead of hardcoding one.
    int imu_freq = VITURE_IMU_FREQUENCY_HIGH;
    while (imu_freq > VITURE_IMU_FREQUENCY_LOW &&
           !xr_device_provider_is_product_support_imu_frequency(pid, VITURE_IMU_MODE_POSE, imu_freq))
        imu_freq--;
    int imu_err = xr_device_provider_open_imu(g_handle, VITURE_IMU_MODE_POSE, imu_freq);
    if (imu_err != VITURE_GLASSES_SUCCESS)
        fprintf(stderr, "open_imu failed: %d (continuing)\n", imu_err);
}

// Configure a native-DOF device (currently Beast) for the chosen 3DOF source.
//   on_device = true  : native mode — the glasses track the head and reproject a
//                       fixed-camera scene rendered by the host (no pose needed).
//   on_device = false : bypass mode — the host renders 3DOF from IMU pose data,
//                       exactly like a regular Gen2 device.
static void native_apply(bool on_device)
{
    g_native_on_device = on_device;

    if (on_device) {
        int rc = xr_device_provider_native_set_mode(g_handle, 1);
        if (rc != VITURE_GLASSES_SUCCESS)
            fprintf(stderr, "native_set_mode(1) failed: %d (continuing)\n", rc);

        rc = xr_device_provider_native_set_display_mode(
            g_handle, VITURE_NATIVE_DISPLAY_MODE_1920_1200_60HZ);
        if (rc != VITURE_GLASSES_SUCCESS)
            fprintf(stderr, "native_set_display_mode failed: %d (continuing)\n", rc);

        rc = xr_device_provider_native_set_dof(g_handle, VITURE_NATIVE_DOF_3);
        if (rc != VITURE_GLASSES_SUCCESS)
            fprintf(stderr, "native_set_dof failed: %d (continuing)\n", rc);

        rc = xr_device_provider_native_recenter_dof(g_handle);
        if (rc != VITURE_GLASSES_SUCCESS)
            fprintf(stderr, "native_recenter_dof failed: %d (continuing)\n", rc);
    } else {
        int rc = xr_device_provider_native_set_mode(g_handle, 0);
        if (rc != VITURE_GLASSES_SUCCESS)
            fprintf(stderr, "native_set_mode(0) failed: %d (continuing)\n", rc);

        // The mode switch only completes once a display mode for the new mode is
        // set. In bypass mode that is the standard VITURE_DISPLAY_MODE_* set.
        rc = xr_device_provider_set_display_mode(g_handle, VITURE_DISPLAY_MODE_1920_1200_60HZ);
        if (rc != VITURE_GLASSES_SUCCESS)
            fprintf(stderr, "set_display_mode failed: %d (continuing)\n", rc);

        start_host_pose_tracking(g_selected_pid);
    }
}

// Connect to a device by PID. For Gen1/Gen2, completes the full lifecycle.
// For Carina, only creates the handle; initialize happens after the user picks DOF.
// Returns false on failure (handle is destroyed and globals are cleared).
static bool try_connect(int pid)
{
    g_handle = xr_device_provider_create(pid);
    if (!g_handle) {
        fprintf(stderr, "xr_device_provider_create failed for PID 0x%04X\n", pid);
        return false;
    }

    g_selected_pid = pid;
    g_device_type  = xr_device_provider_get_device_type(g_handle);
    int len = static_cast<int>(sizeof(g_market_name));
    xr_device_provider_get_market_name(pid, g_market_name, &len);
    printf("Device: Viture %s (%s)\n", g_market_name, device_type_label(g_device_type));

    if (!is_gen1_or_gen2(g_device_type))
        return true;  // Carina: deferred init

    // Gen1/Gen2: complete lifecycle now
    if (xr_device_provider_initialize(g_handle, nullptr, nullptr) != VITURE_GLASSES_SUCCESS) {
        fprintf(stderr, "xr_device_provider_initialize failed\n");
        xr_device_provider_destroy(g_handle);
        g_handle = nullptr; g_selected_pid = -1; g_device_type = -1;
        return false;
    }
    xr_device_provider_register_state_callback(g_handle, StateCallback);
    if (xr_device_provider_start(g_handle) != VITURE_GLASSES_SUCCESS) {
        fprintf(stderr, "xr_device_provider_start failed\n");
        xr_device_provider_shutdown(g_handle);
        xr_device_provider_destroy(g_handle);
        g_handle = nullptr; g_selected_pid = -1; g_device_type = -1;
        return false;
    }
    g_sdk_started = true;
    read_initial_device_state();

    // Native-DOF devices (Beast) defer 3DOF-source configuration until the user
    // picks on-device / on-host in NATIVE_SELECTING; regular Gen1/Gen2 start
    // host pose tracking immediately.
    if (!supports_native_dof(pid))
        start_host_pose_tracking(pid);

    return true;
}

// Scan for devices and attempt to connect if exactly one is found.
// Updates g_found_pids. Returns the next AppState.
static AppState do_scan()
{
    g_found_pids = find_viture_devices();

    if (g_found_pids.empty())
        return AppState::SCANNING;

    if (g_found_pids.size() == 1) {
        if (!try_connect(g_found_pids[0]))
            return AppState::SCANNING;
        if (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA)
            return AppState::CARINA_SELECTING;
        if (supports_native_dof(g_selected_pid))
            return AppState::NATIVE_SELECTING;
        return AppState::TRACKING;
    }

    return AppState::SELECTING_DEV;
}

// ---- Carina lifecycle -------------------------------------------------------

// Called when the user picks a DOF mode. Completes the Carina SDK lifecycle
// (set_dof_type → initialize → start) and launches the poll thread.
// Returns false on failure.
static bool carina_start(bool is_6dof)
{
    g_carina_6dof = is_6dof;

    // Fresh session starts in automatic exposure.
    g_carina_exp_manual  = false;
    g_carina_exp_time_ms = 4.0f;
    g_carina_exp_gain    = 4;

    xr_device_provider_set_dof_type_carina(g_handle, is_6dof ? 1 : 0);

    if (xr_device_provider_initialize(g_handle, nullptr, nullptr) != VITURE_GLASSES_SUCCESS) {
        fprintf(stderr, "xr_device_provider_initialize failed\n");
        xr_device_provider_destroy(g_handle);
        g_handle = nullptr;
        return false;
    }

    xr_device_provider_register_state_callback(g_handle, StateCallback);

    // Stereo camera callback must be registered before start(): the Carina VIO
    // engine captures the callback pointer at start time.
    carina_camera_register(g_handle);

    if (xr_device_provider_start(g_handle) != VITURE_GLASSES_SUCCESS) {
        fprintf(stderr, "xr_device_provider_start failed\n");
        xr_device_provider_shutdown(g_handle);
        xr_device_provider_destroy(g_handle);
        g_handle = nullptr;
        return false;
    }
    g_sdk_started = true;
    read_initial_device_state();

    // Launch pose poll thread
    g_poll_running = true;
    g_poll_thread  = std::thread(carina_poll_fn);
    return true;
}

// Tears down the current Carina session and recreates the handle for re-init.
// Keeps g_selected_pid / g_market_name / g_device_type so the mode-select HUD
// can still show the device name.
// Returns false if the handle could not be recreated (device disconnected).
static bool carina_stop_for_mode_switch()
{
    camera_bg_stop();
    carina_camera_set(false);

    g_poll_running = false;
    if (g_poll_thread.joinable()) g_poll_thread.join();

    xr_device_provider_stop(g_handle);
    xr_device_provider_shutdown(g_handle);
    xr_device_provider_destroy(g_handle);
    g_handle = nullptr;

    g_sdk_started = false;
    g_carina_6dof = false;
    reset_state();

    // Recreate handle ready for next initialize
    g_handle = xr_device_provider_create(g_selected_pid);
    if (!g_handle) {
        fprintf(stderr, "xr_device_provider_create failed after mode switch\n");
        g_selected_pid = -1;
        g_device_type  = -1;
        snprintf(g_market_name, sizeof(g_market_name), "No device");
        return false;
    }
    return true;
}

// Tears down the current native-DOF (Beast) mode config so the user can re-pick
// in NATIVE_SELECTING. Only closes the IMU if on-host (bypass) tracking had
// opened it. The handle stays alive — native/bypass is a runtime command, so no
// re-init is needed (unlike Carina's DOF switch).
static void native_stop_for_mode_switch()
{
    camera_bg_stop();
    if (!g_native_on_device)
        xr_device_provider_close_imu(g_handle, VITURE_IMU_MODE_POSE);
    reset_state();
}

// ---- main -------------------------------------------------------------------

int main()
{
    std::signal(SIGINT, signal_handler);
    xr_device_provider_set_log_level(LOG_LEVEL_ERROR);

    // Open window before any device interaction so all feedback is on-screen.
    SetTraceLogLevel(LOG_WARNING);
    InitWindow(1280, 720, "Viture SDK Demo");
    SetTargetFPS(60);

    Camera3D camera = {};
    camera.position   = { 0.0f, 0.0f,  0.0f };
    camera.target     = { 0.0f, 0.0f, -1.0f };
    camera.up         = { 0.0f, 1.0f,  0.0f };
    camera.fovy       = 70.0f;
    camera.projection = CAMERA_PERSPECTIVE;

    // Initial scan: auto-connect if exactly one device is found.
    g_app_state = do_scan();

    // Timestamp used to throttle the periodic disconnect check (once per second).
    double last_disconnect_check = GetTime();

    // Main render loop
    while (!WindowShouldClose() && g_running) {
        if (IsKeyPressed(KEY_Q) || IsKeyPressed(KEY_ESCAPE))
            break;

        if (IsKeyPressed(KEY_P))
            ToggleFullscreen();

        // ---- SCANNING state: no device found --------------------------------
        if (g_app_state == AppState::SCANNING) {
            if (IsKeyPressed(KEY_R))
                g_app_state = do_scan();

            BeginDrawing();
            ClearBackground(BLACK);
            draw_scanning_hud();
            EndDrawing();
            continue;
        }

        // ---- SELECTING_DEV state: multiple devices, user picks one ----------
        if (g_app_state == AppState::SELECTING_DEV) {
            for (int i = 0; i < static_cast<int>(g_found_pids.size()) && i < 9; ++i) {
                if (IsKeyPressed((KeyboardKey)(KEY_ONE + i))) {
                    if (try_connect(g_found_pids[i])) {
                        if (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA)
                            g_app_state = AppState::CARINA_SELECTING;
                        else if (supports_native_dof(g_selected_pid))
                            g_app_state = AppState::NATIVE_SELECTING;
                        else
                            g_app_state = AppState::TRACKING;
                        last_disconnect_check = GetTime();
                    } else {
                        g_app_state = AppState::SCANNING;
                    }
                    break;
                }
            }

            BeginDrawing();
            ClearBackground(BLACK);
            draw_selecting_dev_hud(g_found_pids);
            EndDrawing();
            continue;
        }

        // ---- DISCONNECTED state: device was lost mid-run --------------------
        if (g_app_state == AppState::DISCONNECTED) {
            if (IsKeyPressed(KEY_R)) {
                g_app_state = do_scan();
                last_disconnect_check = GetTime();
            }

            BeginDrawing();
            ClearBackground(BLACK);
            draw_disconnected_hud();
            EndDrawing();
            continue;
        }

        // ---- Periodic disconnect check (CARINA_SELECTING + NATIVE_SELECTING +
        // TRACKING) ----------------------------------------------------------
        // Runs once per second: if the selected PID is no longer on the USB bus,
        // tear down the session and show the disconnected screen.
        {
            double now = GetTime();
            if (now - last_disconnect_check >= 1.0) {
                last_disconnect_check = now;
                std::vector<int> cur = find_viture_devices();
                if (std::find(cur.begin(), cur.end(), g_selected_pid) == cur.end()) {
                    printf("Device disconnected.\n");
                    full_teardown();
                    g_app_state = AppState::DISCONNECTED;

                    BeginDrawing();
                    ClearBackground(BLACK);
                    draw_disconnected_hud();
                    EndDrawing();
                    continue;
                }
            }
        }

        // ---- CARINA_SELECTING state: Carina connected, pick 3DOF or 6DOF ---
        if (g_app_state == AppState::CARINA_SELECTING) {
            if (IsKeyPressed(KEY_THREE) || IsKeyPressed(KEY_KP_3)) {
                if (carina_start(false)) {
                    g_app_state = AppState::TRACKING;
                    last_disconnect_check = GetTime();
                } else {
                    g_app_state = AppState::DISCONNECTED;
                }
            } else if (IsKeyPressed(KEY_SIX) || IsKeyPressed(KEY_KP_6)) {
                if (carina_start(true)) {
                    g_app_state = AppState::TRACKING;
                    last_disconnect_check = GetTime();
                } else {
                    g_app_state = AppState::DISCONNECTED;
                }
            }

            BeginDrawing();
            ClearBackground(BLACK);
            draw_carina_select_hud(g_market_name);
            EndDrawing();
            continue;
        }

        // ---- NATIVE_SELECTING state: Beast connected, pick 3DOF source ------
        if (g_app_state == AppState::NATIVE_SELECTING) {
            if (IsKeyPressed(KEY_ONE) || IsKeyPressed(KEY_KP_1)) {
                native_apply(true);   // on-device (native mode)
                g_app_state = AppState::TRACKING;
                last_disconnect_check = GetTime();
            } else if (IsKeyPressed(KEY_TWO) || IsKeyPressed(KEY_KP_2)) {
                native_apply(false);  // on-host (bypass mode)
                g_app_state = AppState::TRACKING;
                last_disconnect_check = GetTime();
            }

            BeginDrawing();
            ClearBackground(BLACK);
            draw_native_select_hud(g_market_name);
            EndDrawing();
            continue;
        }

        // ====================================================================
        // TRACKING state
        // ====================================================================

        // Read IMU/pose data
        float local_euler[3]    = {};
        float local_pos[3]      = {};
        float local_cquat[4]    = {};
        int   local_pose_status = 1;  // 0=stable, 1=unstable; Carina 6DOF only
        bool  have_pose         = false;
        {
            std::lock_guard<std::mutex> lk(g_imu.mtx);
            if (g_imu.fresh) {
                memcpy(local_euler, g_imu.euler,       sizeof(local_euler));
                memcpy(local_pos,   g_imu.pos,         sizeof(local_pos));
                memcpy(local_cquat, g_imu.carina_quat, sizeof(local_cquat));
                local_pose_status = g_imu.pose_status;
                have_pose = true;
            }
        }

        // Gen1/Gen2 and Carina 3DOF: auto-init yaw offset on first frame
        if (have_pose && !g_yaw_init_done &&
            (is_gen1_or_gen2(g_device_type) ||
             (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && !g_carina_6dof))) {
            if (is_gen1_or_gen2(g_device_type)) {
                g_yaw_offset = local_euler[2];
            } else {
                // Carina 3DOF: derive yaw from quaternion forward vector
                Vector3 fwd0 = QuatRotateVec3(local_cquat, {0.0f, 0.0f, -1.0f});
                g_yaw_offset = RAD2DEG * atan2f(fwd0.x, -fwd0.z);
            }
            g_yaw_init_done = true;
        }

        // Carina 6DOF: auto-init pose reference on first valid frame (and after
        // RR / RRR resets clear g_carina_ref_init to re-anchor).
        if (have_pose && !g_carina_ref_init &&
            g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && g_carina_6dof) {
            memcpy(g_carina_quat_ref, local_cquat, sizeof(g_carina_quat_ref));
            memcpy(g_carina_pos_ref,  local_pos,   sizeof(g_carina_pos_ref));
            g_carina_ref_init = true;
        }

        // R key: recenter / yaw reset
        // Native-DOF (Beast) on-device: on-device recenter via SDK.
        // Carina 6DOF: software recenter (all axes via pose reference).
        // All other modes (incl. Beast on-host): software yaw offset.
        if (IsKeyPressed(KEY_R)) {
            if (supports_native_dof(g_selected_pid) && g_native_on_device) {
                xr_device_provider_native_recenter_dof(g_handle);
            } else if (have_pose) {
                if (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && g_carina_6dof) {
                    memcpy(g_carina_quat_ref, local_cquat, sizeof(g_carina_quat_ref));
                    memcpy(g_carina_pos_ref,  local_pos,   sizeof(g_carina_pos_ref));
                } else {
                    if (is_gen1_or_gen2(g_device_type)) {
                        g_yaw_offset = local_euler[2];
                    } else {
                        Vector3 fwd0 = QuatRotateVec3(local_cquat, {0.0f, 0.0f, -1.0f});
                        g_yaw_offset = RAD2DEG * atan2f(fwd0.x, -fwd0.z);
                    }
                }
            }
        }

        // T key (Carina): SDK-level yaw + position reset.
        // Pass current pose as origin so the SDK relocates the coordinate frame to
        // the user's present position and heading.  Reset software reference to zero
        // so subsequent poses from the SDK are consumed without additional offset.
        if (IsKeyPressed(KEY_T) && have_pose &&
            g_device_type == XR_DEVICE_TYPE_VITURE_CARINA) {
            float origin[7];
            {
                std::lock_guard<std::mutex> lk(g_imu.mtx);
                origin[0] = g_imu.pos[0];
                origin[1] = g_imu.pos[1];
                origin[2] = g_imu.pos[2];
                origin[3] = g_imu.carina_quat[0];
                origin[4] = g_imu.carina_quat[1];
                origin[5] = g_imu.carina_quat[2];
                origin[6] = g_imu.carina_quat[3];
            }
            xr_device_provider_reset_origin_carina(g_handle, origin);
            g_carina_quat_ref[0] = 1.0f;
            g_carina_quat_ref[1] = g_carina_quat_ref[2] = g_carina_quat_ref[3] = 0.0f;
            memset(g_carina_pos_ref, 0, sizeof(g_carina_pos_ref));
            g_carina_ref_init = true;
            g_yaw_offset = 0.0f;
        }

        // Y key (Carina): full VIO re-initialisation.
        // Same software reference reset as T.
        if (IsKeyPressed(KEY_Y) && have_pose &&
            g_device_type == XR_DEVICE_TYPE_VITURE_CARINA) {
            xr_device_provider_reset_pose_carina(g_handle);
            g_carina_quat_ref[0] = 1.0f;
            g_carina_quat_ref[1] = g_carina_quat_ref[2] = g_carina_quat_ref[3] = 0.0f;
            memset(g_carina_pos_ref, 0, sizeof(g_carina_pos_ref));
            g_carina_ref_init = true;
            g_yaw_offset = 0.0f;
        }

        // W key: toggle camera background (devices with USB camera only)
        if (IsKeyPressed(KEY_W) && camera_bg_supported(g_selected_pid)) {
            if (camera_bg_is_streaming())
                camera_bg_stop();
            else
                camera_bg_start(g_selected_pid);
        }

        // C key (Carina only): toggle the VIO stereo grayscale camera preview
        if (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && IsKeyPressed(KEY_C))
            carina_camera_toggle();

        // Carina camera exposure control (Carina only).
        //   [E] auto/manual toggle, [ / ] exposure time, - / = gain
        if (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && g_sdk_started) {
            bool exp_dirty = false;
            if (IsKeyPressed(KEY_E)) {
                g_carina_exp_manual = !g_carina_exp_manual;
                if (g_carina_exp_manual) exp_dirty = true;                    // push current manual values
                else xr_device_provider_set_auto_exposure_carina(g_handle);   // back to auto
            }
            if (g_carina_exp_manual) {
                if (IsKeyPressed(KEY_LEFT_BRACKET))  { g_carina_exp_time_ms -= 0.25f; exp_dirty = true; }
                if (IsKeyPressed(KEY_RIGHT_BRACKET)) { g_carina_exp_time_ms += 0.25f; exp_dirty = true; }
                if (IsKeyPressed(KEY_MINUS))         { g_carina_exp_gain    -= 1;     exp_dirty = true; }
                if (IsKeyPressed(KEY_EQUAL))         { g_carina_exp_gain    += 1;     exp_dirty = true; }
                // Clamp locally so the HUD readout matches what the SDK applies.
                if (g_carina_exp_time_ms < 0.01f) g_carina_exp_time_ms = 0.01f;
                if (g_carina_exp_time_ms > 8.0f)  g_carina_exp_time_ms = 8.0f;
                if (g_carina_exp_gain < 0)  g_carina_exp_gain = 0;
                if (g_carina_exp_gain > 15) g_carina_exp_gain = 15;
                if (exp_dirty)
                    xr_device_provider_set_manual_exposure_carina(
                        g_handle, g_carina_exp_time_ms, g_carina_exp_gain);
            }
        }

        // S key (Carina only): switch DOF mode → back to mode selection
        if (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && IsKeyPressed(KEY_S)) {
            if (!carina_stop_for_mode_switch()) {
                g_app_state = AppState::DISCONNECTED;
            } else {
                g_app_state = AppState::CARINA_SELECTING;
                last_disconnect_check = GetTime();
            }

            BeginDrawing();
            ClearBackground(BLACK);
            if (g_app_state == AppState::CARINA_SELECTING)
                draw_carina_select_hud(g_market_name);
            else
                draw_disconnected_hud();
            EndDrawing();
            continue;
        }

        // S key (Beast native-DOF): switch 3DOF source → back to mode selection
        if (supports_native_dof(g_selected_pid) && IsKeyPressed(KEY_S)) {
            native_stop_for_mode_switch();
            g_app_state = AppState::NATIVE_SELECTING;
            last_disconnect_check = GetTime();

            BeginDrawing();
            ClearBackground(BLACK);
            draw_native_select_hud(g_market_name);
            EndDrawing();
            continue;
        }

        // Update camera
        if (supports_native_dof(g_selected_pid) && g_native_on_device) {
            // Native-DOF devices on-device (Beast): glasses do head tracking
            // on-device; host renders a fixed-camera scene that the device
            // reprojects. On-host (bypass) falls into the Gen2 branch below.
            camera.position = { 0.0f, 0.0f, 0.0f };
            camera.target   = { 0.0f, 0.0f, -1.0f };
            camera.up       = { 0.0f, 1.0f, 0.0f };
        } else if (is_gen1_or_gen2(g_device_type) && have_pose) {
            float yaw_rel = local_euler[2] - g_yaw_offset;
            // NWU: positive yaw = left turn → negate; positive pitch = down → negate
            float az = DEG2RAD * (-yaw_rel);
            float el = DEG2RAD * (-local_euler[1]);
            Vector3 fwd = { sinf(az) * cosf(el), sinf(el), -cosf(az) * cosf(el) };
            camera.target = {
                camera.position.x + fwd.x,
                camera.position.y + fwd.y,
                camera.position.z + fwd.z
            };
            // Apply roll about the view axis so head tilt is reflected. Build the
            // no-roll up from world-up, then rotate it around forward by roll.
            Vector3 right = { -fwd.z, 0.0f, fwd.x }; // cross(fwd, worldUp={0,1,0})
            float rlen = sqrtf(right.x * right.x + right.y * right.y + right.z * right.z);
            if (rlen > 1e-6f) { right.x /= rlen; right.y /= rlen; right.z /= rlen; }
            Vector3 up0 = { // cross(right, fwd)
                right.y * fwd.z - right.z * fwd.y,
                right.z * fwd.x - right.x * fwd.z,
                right.x * fwd.y - right.y * fwd.x
            };
            float rl = DEG2RAD * local_euler[0];
            float cr = cosf(rl), sr = sinf(rl);
            camera.up = {
                up0.x * cr + right.x * sr,
                up0.y * cr + right.y * sr,
                up0.z * cr + right.z * sr
            };
            camera.position = { 0.0f, 0.0f, 0.0f };
        } else if (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && have_pose) {
            if (g_carina_6dof) {
                // Full 6DOF: apply software recenter offset, then scale position so
                // small physical movement maps to a noticeable virtual displacement.
                const float kPosScale = 3.0f;
                float q_ref_conj[4] = { g_carina_quat_ref[0], -g_carina_quat_ref[1],
                                        -g_carina_quat_ref[2], -g_carina_quat_ref[3] };
                float q_rel[4];
                QuatMul(q_rel, q_ref_conj, local_cquat);
                Vector3 dp = { local_pos[0] - g_carina_pos_ref[0],
                               local_pos[1] - g_carina_pos_ref[1],
                               local_pos[2] - g_carina_pos_ref[2] };
                Vector3 rel_pos = QuatRotateVec3(q_ref_conj, dp);
                camera.position = { rel_pos.x * kPosScale,
                                    rel_pos.y * kPosScale,
                                    rel_pos.z * kPosScale };
                Vector3 fwd = QuatRotateVec3(q_rel, {0.0f, 0.0f, -1.0f});
                camera.target = {
                    camera.position.x + fwd.x,
                    camera.position.y + fwd.y,
                    camera.position.z + fwd.z
                };
                camera.up = QuatRotateVec3(q_rel, {0.0f, 1.0f, 0.0f});
            } else {
                // 3DOF Carina: fixed position, yaw-offset orientation from quaternion
                camera.position = { 0.0f, 0.0f, 0.0f };
                Vector3 fwd0 = QuatRotateVec3(local_cquat, {0.0f, 0.0f, -1.0f});
                float yaw   = RAD2DEG * atan2f(fwd0.x, -fwd0.z);
                float pitch = RAD2DEG * asinf(fwd0.y);
                float yaw_rel = yaw - g_yaw_offset;
                float az = DEG2RAD * yaw_rel;
                float el = DEG2RAD * pitch;
                camera.target = {
                    camera.position.x + sinf(az) * cosf(el),
                    camera.position.y + sinf(el),
                    camera.position.z - cosf(az) * cosf(el)
                };
                camera.up = { 0.0f, 1.0f, 0.0f };
            }
        }

        // Snapshot device state
        int snap_bri, snap_vol, snap_film;
        {
            std::lock_guard<std::mutex> lk(g_dev_state_mtx);
            snap_bri  = g_brightness;
            snap_vol  = g_volume;
            snap_film = g_film;
        }

        // Carina 6DOF: only render the 3D scene when tracking is stable
        const bool tracking_stable =
            !(g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && g_carina_6dof) ||
            (have_pose && local_pose_status == 0);

        BeginDrawing();
        ClearBackground(BLACK);

        camera_bg_update();
        camera_bg_draw();

        if (tracking_stable) {
            BeginMode3D(camera);
            if (g_device_type == XR_DEVICE_TYPE_VITURE_CARINA && g_carina_6dof)
                DrawScene6DOF(camera);
            else
                DrawScene3DOF(camera);
            EndMode3D();
        }

        // Carina stereo grayscale camera preview (top-right overlay)
        carina_camera_update();
        carina_camera_draw();

        draw_tracking_hud(local_euler, local_pos, local_cquat,
                          have_pose, snap_bri, snap_vol, snap_film, tracking_stable,
                          g_market_name, g_sn_hash, g_device_type, g_selected_pid,
                          g_carina_6dof, g_native_on_device, g_yaw_offset,
                          camera_bg_supported(g_selected_pid),
                          camera_bg_is_streaming(),
                          g_carina_exp_manual, g_carina_exp_time_ms, g_carina_exp_gain);
        EndDrawing();
    }

    // Cleanup
    full_teardown();
    CloseWindow();
    return 0;
}

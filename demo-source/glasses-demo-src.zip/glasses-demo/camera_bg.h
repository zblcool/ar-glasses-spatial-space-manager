// Copyright (C) 2026 Viture Inc. All rights reserved.

#pragma once

#include <mutex>
#include <vector>

#include "raylib.h"
#include "viture_camera_provider.h"
#include "viture_result.h"
#ifdef __APPLE__
#include "macos/camera_permission.h"
#endif

/**
 * camera_bg — wraps viture_camera_provider for use in glasses-demo.
 *
 * The camera delivers 1920x1080 MJPEG frames on a dedicated SDK thread.
 * The frame callback stores the raw JPEG bytes under a mutex; the main
 * thread picks them up each frame in camera_bg_update(), decodes them
 * via Raylib's LoadImageFromMemory, and uploads to a GPU texture that is
 * drawn as a full-screen background before the 3D scene.
 *
 * NOTE: this header defines a static global (g_cam) and must only be
 * included from a single translation unit (main.cpp).
 */

struct CameraBgState {
    // Written by camera callback thread, read by main thread.
    std::mutex           mtx;
    std::vector<uint8_t> pending;   // raw MJPEG bytes of latest unprocessed frame
    bool                 fresh = false;

    // Main thread only.
    XRCameraProviderHandle handle    = nullptr;
    Texture2D              texture   = {};
    bool                   has_tex   = false;
    bool                   streaming = false;
};

static CameraBgState g_cam;

static void camera_frame_cb(const XRCameraFrame* frame, void* /*user_data*/)
{
    if (!frame || frame->format != XR_CAMERA_FORMAT_MJPEG
            || !frame->data || frame->size == 0)
        return;
    std::lock_guard<std::mutex> lk(g_cam.mtx);
    g_cam.pending.assign(frame->data, frame->data + frame->size);
    g_cam.fresh = true;
}

// Returns true if the given glasses PID has USB camera support.
inline bool camera_bg_supported(int glasses_pid)
{
    return xr_camera_provider_get_camera_pid(glasses_pid) != 0;
}

inline bool camera_bg_is_streaming()
{
    return g_cam.streaming;
}

// Start camera streaming. Returns true on success.
// No-op (returns true) if already streaming.
inline bool camera_bg_start(int glasses_pid)
{
    if (g_cam.streaming) return true;

#ifdef __APPLE__
    if (!request_camera_permission()) {
        fprintf(stderr, "[camera] camera permission denied\n");
        return false;
    }
#endif

    int cam_vid = xr_camera_provider_get_camera_vid(glasses_pid);
    int cam_pid = xr_camera_provider_get_camera_pid(glasses_pid);
    if (cam_pid == 0) return false;

    g_cam.handle = xr_camera_provider_create(cam_vid, cam_pid);
    if (!g_cam.handle) {
        fprintf(stderr, "[camera] xr_camera_provider_create failed\n");
        return false;
    }
    if (xr_camera_provider_start(g_cam.handle, camera_frame_cb, nullptr)
            != VITURE_GLASSES_SUCCESS) {
        fprintf(stderr, "[camera] xr_camera_provider_start failed\n");
        xr_camera_provider_destroy(g_cam.handle);
        g_cam.handle = nullptr;
        return false;
    }
    g_cam.streaming = true;
    return true;
}

// Stop camera streaming and release all GPU and SDK resources.
// Safe to call when not streaming.
inline void camera_bg_stop()
{
    if (!g_cam.streaming) return;

    xr_camera_provider_stop(g_cam.handle);
    xr_camera_provider_destroy(g_cam.handle);
    g_cam.handle    = nullptr;
    g_cam.streaming = false;

    {
        std::lock_guard<std::mutex> lk(g_cam.mtx);
        g_cam.pending.clear();
        g_cam.fresh = false;
    }

    if (g_cam.has_tex) {
        UnloadTexture(g_cam.texture);
        g_cam.texture = {};
        g_cam.has_tex = false;
    }
}

// Decode and upload the latest camera frame to GPU.
// Must be called from the main (render) thread each frame, inside BeginDrawing().
// Returns true if a valid texture is ready to draw.
inline bool camera_bg_update()
{
    if (!g_cam.streaming) return false;

    // Swap out the pending buffer under lock (fast path).
    std::vector<uint8_t> local_jpeg;
    {
        std::lock_guard<std::mutex> lk(g_cam.mtx);
        if (!g_cam.fresh) return g_cam.has_tex;
        local_jpeg.swap(g_cam.pending);
        g_cam.fresh = false;
    }

    // Decode JPEG outside the lock.
    Image img = LoadImageFromMemory(".jpg",
                                    local_jpeg.data(),
                                    static_cast<int>(local_jpeg.size()));
    if (img.data == nullptr) return g_cam.has_tex;

    ImageFormat(&img, PIXELFORMAT_UNCOMPRESSED_R8G8B8A8);

    if (!g_cam.has_tex) {
        g_cam.texture = LoadTextureFromImage(img);
        g_cam.has_tex = (g_cam.texture.id > 0);
    } else {
        UpdateTexture(g_cam.texture, img.data);
    }
    UnloadImage(img);
    return g_cam.has_tex;
}

// Draw the latest camera frame scaled to fill the screen.
// Call after ClearBackground(), before BeginMode3D().
inline void camera_bg_draw()
{
    if (!g_cam.has_tex) return;
    Rectangle src = { 0.0f, 0.0f,
                      static_cast<float>(g_cam.texture.width),
                      static_cast<float>(g_cam.texture.height) };
    Rectangle dst = { 0.0f, 0.0f,
                      static_cast<float>(GetScreenWidth()),
                      static_cast<float>(GetScreenHeight()) };
    DrawTexturePro(g_cam.texture, src, dst, { 0.0f, 0.0f }, 0.0f, WHITE);
}

// Copyright (C) 2026 Viture Inc. All rights reserved.

#pragma once

#include "raylib.h"
#include "rlgl.h"

// Eye height above floor in metres (camera origin is at eye level).
static constexpr float kEyeHeight6DOF = 1.6f;

/**
 * DrawScene6DOF - 1 m colorful cube at the world origin for 6DOF walk-around.
 *
 * Per-face color convention (OpenGL/Raylib right-handed Y-up):
 *   +X: Red      -X: Sky blue
 *   +Y: Green    -Y: Magenta
 *   +Z: Blue     -Z: Yellow
 *
 * Supporting elements:
 *   - Floor grid 10 x 10 m
 *   - Origin axis lines (X=Red, Y=Green, Z=Blue), 0.5 m each
 *   - Wireframe bounding box for depth cue
 *
 * Call between BeginMode3D() and EndMode3D().
 */
inline void DrawScene6DOF(Camera3D /*camera*/)
{
    // Floor grid at foot level: camera origin is eye height above the floor.
    rlPushMatrix();
    rlTranslatef(0.0f, -kEyeHeight6DOF, 0.0f);
    DrawGrid(20, 0.5f);
    rlPopMatrix();

    // Per-face colored cube: 2 m in front of the tracking origin,
    // centred at y=0 so the camera at (0, 0, 0) looks directly at its centre.
    const Vector3 C = { 0.0f, 0.0f, -2.0f };
    const float   H = 0.5f;   // half-side
    const float   T = 0.02f;  // face slab thickness

    DrawCube({ C.x + H, C.y,     C.z     }, T,    1.0f, 1.0f, RED);      // +X
    DrawCube({ C.x - H, C.y,     C.z     }, T,    1.0f, 1.0f, SKYBLUE);  // -X
    DrawCube({ C.x,     C.y + H, C.z     }, 1.0f, T,    1.0f, GREEN);    // +Y
    DrawCube({ C.x,     C.y - H, C.z     }, 1.0f, T,    1.0f, MAGENTA);  // -Y
    DrawCube({ C.x,     C.y,     C.z + H }, 1.0f, 1.0f, T,    BLUE);     // +Z
    DrawCube({ C.x,     C.y,     C.z - H }, 1.0f, 1.0f, T,    YELLOW);   // -Z
    DrawCubeWires(C, 1.0f, 1.0f, 1.0f, DARKGRAY);

    // Axis lines at cube centre
    DrawLine3D(C, { C.x + H, C.y,     C.z     }, RED);
    DrawLine3D(C, { C.x,     C.y + H, C.z     }, GREEN);
    DrawLine3D(C, { C.x,     C.y,     C.z + H }, BLUE);
}

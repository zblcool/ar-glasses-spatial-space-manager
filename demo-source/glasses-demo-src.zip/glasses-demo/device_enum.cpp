// Copyright (C) 2026 Viture Inc. All rights reserved.
//
// USB device enumeration (HID primary + native USB fallback).
// Kept in a separate translation unit so that platform SDK headers
// (windows.h/setupapi.h, IOKit, dirent.h) are never included in the same
// TU as raylib.h, which conflicts with several Windows SDK declarations.

#define _CRT_SECURE_NO_WARNINGS  // suppress sscanf deprecation on MSVC

#include "device_enum.h"

#include <algorithm>
#include <cstdio>
#include <cstring>

#if defined(_WIN32)
#  include <windows.h>
#  include <setupapi.h>
#  pragma comment(lib, "setupapi.lib")
#elif defined(__APPLE__)
#  include <CoreFoundation/CoreFoundation.h>
#  include <IOKit/IOKitLib.h>
#  include <IOKit/usb/IOUSBLib.h>
#else
#  include <dirent.h>
#endif

#include "hidapi.h"
#include "viture_glasses_provider.h"

// ---- Platform helpers -------------------------------------------------------

#if defined(__APPLE__)
static bool get_usb_property(io_service_t service, const char* key, uint16_t* out)
{
    CFStringRef keyStr = CFStringCreateWithCString(kCFAllocatorDefault, key, kCFStringEncodingUTF8);
    CFTypeRef   prop   = IORegistryEntryCreateCFProperty(service, keyStr, kCFAllocatorDefault, 0);
    CFRelease(keyStr);
    if (!prop) return false;
    bool ok = false;
    if (CFGetTypeID(prop) == CFNumberGetTypeID())
        ok = CFNumberGetValue((CFNumberRef)prop, kCFNumberShortType, out);
    CFRelease(prop);
    return ok;
}
#elif !defined(_WIN32)
static bool read_hex_from_file(const char* path, int* out)
{
    FILE* f = std::fopen(path, "r");
    if (!f) return false;
    char buf[64] = {};
    bool ok = std::fgets(buf, sizeof(buf), f) != nullptr;
    std::fclose(f);
    if (!ok) return false;
    char* end = nullptr;
    long v = std::strtol(buf, &end, 16);
    if (end == buf) return false;
    *out = static_cast<int>(v);
    return true;
}
#endif

// ---- Fallback enumeration ---------------------------------------------------

// Finds devices invisible to hidapi (e.g. Carina bulk-transfer).
static void find_viture_devices_fallback(std::vector<int>& pids)
{
#if defined(_WIN32)
    HDEVINFO info = SetupDiGetClassDevsA(NULL, "USB", NULL, DIGCF_PRESENT | DIGCF_ALLCLASSES);
    if (info == INVALID_HANDLE_VALUE) return;
    SP_DEVINFO_DATA devData;
    devData.cbSize = sizeof(devData);
    for (DWORD i = 0; SetupDiEnumDeviceInfo(info, i, &devData); ++i) {
        DWORD regType = 0;
        BYTE  buf[4096] = {};
        if (!SetupDiGetDeviceRegistryPropertyA(info, &devData, SPDRP_HARDWAREID,
                                               &regType, buf, sizeof(buf), NULL))
            continue;
        for (const char* p = reinterpret_cast<const char*>(buf); *p; p += std::strlen(p) + 1) {
            const char* vidPos = strstr(p, "VID_");
            const char* pidPos = strstr(p, "PID_");
            if (!vidPos || !pidPos) continue;
            unsigned int vid = 0, pid = 0;
            if (sscanf(vidPos + 4, "%4x", &vid) == 1 &&
                sscanf(pidPos + 4, "%4x", &pid) == 1 && vid == 0x35CA) {
                if (xr_device_provider_is_product_id_valid(static_cast<int>(pid)) &&
                    std::find(pids.begin(), pids.end(), static_cast<int>(pid)) == pids.end())
                    pids.push_back(static_cast<int>(pid));
            }
        }
    }
    SetupDiDestroyDeviceInfoList(info);
#elif defined(__APPLE__)
    CFMutableDictionaryRef match = IOServiceMatching(kIOUSBDeviceClassName);
    if (!match) return;
    io_iterator_t it = 0;
    if (IOServiceGetMatchingServices(0, match, &it) != KERN_SUCCESS || !it) return;
    io_service_t svc;
    while ((svc = IOIteratorNext(it))) {
        uint16_t vid = 0, pid = 0;
        if (get_usb_property(svc, kUSBVendorID, &vid) && vid == 0x35CA &&
            get_usb_property(svc, kUSBProductID, &pid) &&
            xr_device_provider_is_product_id_valid(static_cast<int>(pid))) {
            if (std::find(pids.begin(), pids.end(), static_cast<int>(pid)) == pids.end())
                pids.push_back(static_cast<int>(pid));
        }
        IOObjectRelease(svc);
    }
    IOObjectRelease(it);
#else
    DIR* dir = opendir("/sys/bus/usb/devices");
    if (!dir) return;
    struct dirent* ent;
    while ((ent = readdir(dir)) != nullptr) {
        if (ent->d_name[0] == '.' || std::strchr(ent->d_name, ':')) continue;
        char vpath[512], ppath[512];
        std::snprintf(vpath, sizeof(vpath), "/sys/bus/usb/devices/%s/idVendor",  ent->d_name);
        std::snprintf(ppath, sizeof(ppath), "/sys/bus/usb/devices/%s/idProduct", ent->d_name);
        int vid = 0, pid = 0;
        if (!read_hex_from_file(vpath, &vid) || vid != 0x35CA) continue;
        if (!read_hex_from_file(ppath, &pid)) continue;
        if (xr_device_provider_is_product_id_valid(pid) &&
            std::find(pids.begin(), pids.end(), pid) == pids.end())
            pids.push_back(pid);
    }
    closedir(dir);
#endif
}

// ---- Primary enumeration ----------------------------------------------------

std::vector<int> find_viture_devices()
{
    std::vector<int> pids;

    if (hid_init() == 0) {
        hid_device_info* devs = hid_enumerate(0, 0);
        for (hid_device_info* cur = devs; cur; cur = cur->next) {
            if (cur->vendor_id != 0x35CA) continue;
            int pid = static_cast<int>(cur->product_id);
            if (xr_device_provider_is_product_id_valid(pid) &&
                std::find(pids.begin(), pids.end(), pid) == pids.end())
                pids.push_back(pid);
        }
        if (devs) hid_free_enumeration(devs);
        hid_exit();
    }

    find_viture_devices_fallback(pids);

    return pids;
}

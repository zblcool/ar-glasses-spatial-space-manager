// Copyright (C) 2026 Viture Inc. All rights reserved.

#pragma once

#include "raylib.h"
#include "rlgl.h"

// Eye height above floor in metres (camera origin is at eye level).
static constexpr float kEyeHeight3DOF = 1.6f;

/**
 * DrawScene3DOF - 3DOF virtual room with colored landmark boxes.
 *
 * The viewer stands at origin; only orientation changes each frame.
 * Raylib coordinate system: right-handed, Y-up.
 *
 * Compass mapping:
 *   North (-Z) = Red      East (+X) = Green
 *   South (+Z) = Blue     West (-X) = Yellow
 *   Up    (+Y) = White sphere
 *
 * Looking toward a direction brings the matching colored box to the center of
 * view, which lets the user immediately verify that the IMU mapping is correct.
 *
 * Call between BeginMode3D() and EndMode3D().
 */
inline void DrawScene3DOF(Camera3D /*camera*/)
{
    // Floor grid at foot level: camera origin is eye height above the floor.
    rlPushMatrix();
    rlTranslatef(0.0f, -kEyeHeight3DOF, 0.0f);
    DrawGrid(20, 0.5f);
    rlPopMatrix();

    // Landmark cubes: 1 m sides, 3 m from origin, centred at eye level (y=0)
    DrawCube({  0.0f, 0.0f, -3.0f }, 1.0f, 1.0f, 1.0f, RED);     // North (-Z)
    DrawCube({  3.0f, 0.0f,  0.0f }, 1.0f, 1.0f, 1.0f, GREEN);   // East  (+X)
    DrawCube({  0.0f, 0.0f,  3.0f }, 1.0f, 1.0f, 1.0f, BLUE);    // South (+Z)
    DrawCube({ -3.0f, 0.0f,  0.0f }, 1.0f, 1.0f, 1.0f, YELLOW);  // West  (-X)

    // Wireframe outlines for depth cue
    DrawCubeWires({  0.0f, 0.0f, -3.0f }, 1.0f, 1.0f, 1.0f, MAROON);
    DrawCubeWires({  3.0f, 0.0f,  0.0f }, 1.0f, 1.0f, 1.0f, DARKGREEN);
    DrawCubeWires({  0.0f, 0.0f,  3.0f }, 1.0f, 1.0f, 1.0f, DARKBLUE);
    DrawCubeWires({ -3.0f, 0.0f,  0.0f }, 1.0f, 1.0f, 1.0f, ORANGE);

    // Overhead sphere — look up to see it
    DrawSphere({ 0.0f, 1.5f, 0.0f }, 0.5f, WHITE);
    DrawSphereWires({ 0.0f, 1.5f, 0.0f }, 0.5f, 8, 8, GRAY);
}

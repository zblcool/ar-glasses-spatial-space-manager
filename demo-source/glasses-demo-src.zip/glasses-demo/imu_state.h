// Copyright (C) 2026 Viture Inc. All rights reserved.

#pragma once

#include <cstring>
#include <mutex>

#include "raylib.h"

/**
 * Thread-safe pose state shared between the SDK thread and the render thread.
 *
 * Write path (SDK callback / Carina polling thread):
 *   lock mtx → memcpy data → fresh = true → unlock
 *
 * Read path (render thread):
 *   lock mtx → copy to local struct → unlock → render from local copy
 */
struct PoseState {
    std::mutex mtx;

    // Gen1 / Gen2 — written by VitureImuPoseCallback
    float euler[3]       = {};  // [roll, pitch, yaw] degrees, North-West-Up frame
    float quat[4]        = {};  // [w, x, y, z]

    // Carina (Luma Ultra) — written by get_gl_pose_carina polling thread
    float pos[3]         = {};  // [x, y, z] metres, OpenGL convention (Y-up, right-handed)
    float carina_quat[4] = {};  // [w, x, y, z]
    int   pose_status    = 1;   // 0 = stable, 1 = unstable (matches get_gl_pose_carina output)

    bool fresh = false;
};

/**
 * Multiply two unit quaternions: out = q1 * q2, all in [w, x, y, z] order.
 */
inline void QuatMul(float out[4], const float q1[4], const float q2[4])
{
    float w1 = q1[0], x1 = q1[1], y1 = q1[2], z1 = q1[3];
    float w2 = q2[0], x2 = q2[1], y2 = q2[2], z2 = q2[3];
    out[0] = w1*w2 - x1*x2 - y1*y2 - z1*z2;
    out[1] = w1*x2 + x1*w2 + y1*z2 - z1*y2;
    out[2] = w1*y2 - x1*z2 + y1*w2 + z1*x2;
    out[3] = w1*z2 + x1*y2 - y1*x2 + z1*w2;
}

/**
 * Rotate vector v by unit quaternion q = [w, x, y, z].
 *
 * Uses the Rodrigues formula:
 *   t   = 2 * (q_vec x v)
 *   v'  = v + w*t + (q_vec x t)
 */
inline Vector3 QuatRotateVec3(const float q[4], Vector3 v)
{
    float w  = q[0], qx = q[1], qy = q[2], qz = q[3];
    float tx = 2.0f * (qy * v.z - qz * v.y);
    float ty = 2.0f * (qz * v.x - qx * v.z);
    float tz = 2.0f * (qx * v.y - qy * v.x);
    return {
        v.x + w * tx + (qy * tz - qz * ty),
        v.y + w * ty + (qz * tx - qx * tz),
        v.z + w * tz + (qx * ty - qy * tx),
    };
}

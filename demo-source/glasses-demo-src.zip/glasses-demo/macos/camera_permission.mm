// Copyright (C) 2026 Viture Inc. All rights reserved.

#import <AVFoundation/AVFoundation.h>
#include <dispatch/dispatch.h>

#include "camera_permission.h"

bool request_camera_permission(void) {
    AVAuthorizationStatus status =
        [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];

    if (status == AVAuthorizationStatusAuthorized)  return true;
    if (status == AVAuthorizationStatusDenied ||
        status == AVAuthorizationStatusRestricted)  return false;

    // AVAuthorizationStatusNotDetermined: show the system dialog and wait.
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    __block bool granted = false;
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo
                            completionHandler:^(BOOL g) {
        granted = g;
        dispatch_semaphore_signal(sem);
    }];
    dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
    return granted;
}

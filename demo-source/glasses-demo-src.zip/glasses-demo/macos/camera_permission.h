// Copyright (C) 2026 Viture Inc. All rights reserved.

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Synchronously request macOS TCC camera permission via AVFoundation.
// Must be called before camera access so macOS shows the permission dialog.
// Returns true if granted, false if denied or restricted.
bool request_camera_permission(void);

#ifdef __cplusplus
}
#endif

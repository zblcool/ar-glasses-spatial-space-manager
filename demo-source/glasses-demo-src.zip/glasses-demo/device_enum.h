// Copyright (C) 2026 Viture Inc. All rights reserved.

#pragma once

#include <vector>

// Primary (HID) + fallback (native USB) enumeration.
// Returns a deduplicated list of Viture product IDs found on the system.
std::vector<int> find_viture_devices();

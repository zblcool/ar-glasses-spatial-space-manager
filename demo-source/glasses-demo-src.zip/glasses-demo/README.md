# glasses-demo

Interactive head-tracking viewer for Viture smart glasses, built on top of
libglasses and raylib. Renders a 3D scene driven by live IMU/pose data from
the connected device.

## Supported devices

```
  Device family   Models
  ------------    ---------------------------------------
  Gen1            Viture One, Viture Lite
  Gen2            Viture Pro, Luma, Luma Pro
  Native DOF      Beast (Gen2 + on-device 3DOF)
  Carina          Luma Ultra
```

> **Native-DOF devices (Beast):** the glasses do head tracking themselves, so the
> demo skips the host-side IMU/pose path and renders a fixed-camera scene that
> the glasses reproject. To get a meaningful experience, mirror or extend the
> host display onto the glasses (1920×1200@60Hz) and run the demo fullscreen
> on the glasses display.

## Build

glasses-demo is a standard CMake project. After dropping the source into your
own tree (or building it inside the SDK source distribution), the only
external dependencies are:

- libglasses — the SDK shared library and its public headers
- raylib — fetched as a CMake dependency by the demo's `CMakeLists.txt`

Build with your platform's regular toolchain:

```bash
cmake -S examples/glasses-demo -B build/glasses-demo \
      -DCMAKE_BUILD_TYPE=Release
cmake --build build/glasses-demo -j
```

The resulting binary is `glasses-demo` (or `glasses-demo.app` on macOS,
`glasses-demo.exe` on Windows). Place the libglasses shared library next to
the binary so the OS loader can find it at runtime.

## Application states

The viewer runs through a simple state machine:

```
  +-------------+   one device (Gen1/Gen2)   +-----------+
  |  SCANNING   | -------------------------> |  TRACKING |<--+
  +-------------+                            +-----------+   |
       |    |                                   |    ^       |
       |    | one device (Carina)               |[S] |       |
       |    v                                   v    |       |
       |  +-----------------+  user picks   +-----------+    |
       |  | CARINA_SELECTING|  [3] or [6]   |  TRACKING |    |
       |  +-----------------+ ------------> |  (Carina) |----+
       |                                    +-----------+    |
       | multiple devices                                    |
       v                                                     |
  +--------------+   user picks [1-9]                        |
  | SELECTING_DEV| ------------------------------------------+
  +--------------+

  Device lost (from TRACKING or CARINA_SELECTING):
  +--------------+   [R]   +-------------+
  | DISCONNECTED | ------> |  SCANNING   |
  +--------------+         +-------------+
```

- **SCANNING**: no device detected; press `R` to rescan.
- **SELECTING_DEV**: multiple devices found; press `1`–`9` to connect to one.
- **CARINA_SELECTING**: Carina device connected; choose tracking mode.
- **TRACKING**: live pose data; 3D scene rendered.
- **DISCONNECTED**: USB device unplugged mid-session; press `R` to rescan.

Disconnect is detected automatically once per second.

## Keyboard controls

```
  Key          State                Action
  ---------    -------------------  -------------------------------------------
  R            SCANNING             Rescan USB bus
  R            DISCONNECTED         Rescan USB bus
  1 - 9        SELECTING_DEV        Connect to the Nth listed device
  3            CARINA_SELECTING     Start in 3DOF mode (orientation only)
  6            CARINA_SELECTING     Start in 6DOF mode (position + orientation)
  R            TRACKING             Recenter (yaw for Gen1/Gen2/Carina 3DOF;
                                    software pose reference for Carina 6DOF;
                                    on-device DOF reset for Beast)
  T            TRACKING (Carina)    Reset origin: SDK-level yaw + position reset
  Y            TRACKING (Carina)    Reset pose: full VIO re-initialisation
  S            TRACKING (Carina)    Switch between 3DOF and 6DOF
  W            TRACKING             Toggle USB camera as scene background
                                    (Luma Pro, Luma Ultra, Beast only)
  P            any                  Toggle fullscreen
  Q / ESC      any                  Quit
```

## 3D scenes

### 3DOF scene (Gen1, Gen2, Carina 3DOF)

Fixed camera position; only orientation changes. Four colored landmark cubes
placed 3 m from the origin at compass directions, and a white sphere overhead.

```
  Direction    Color    Axis
  ---------    -----    ----
  North        Red      -Z
  East         Green    +X
  South        Blue     +Z
  West         Yellow   -X
  Up           White    +Y  (sphere)
```

Floor grid is rendered at 1.6 m below eye level (foot height).

### 6DOF scene (Carina 6DOF)

Camera position and orientation both follow the physical pose. A 1 m
per-face color-coded cube sits 2 m in front of the tracking origin.

```
  Face    Color
  ----    ------
  +X      Red
  -X      Sky blue
  +Y      Green
  -Y      Magenta
  +Z      Blue
  -Z      Yellow
```

Axis indicator lines (red/green/blue) and a wireframe bounding box are drawn
at the cube centre. Floor grid is rendered at 1.6 m below eye level.

Scene is hidden when tracking stability is reported as unstable.

## HUD overlay

The top-left HUD shows:

- Device name and family
- Tracking mode (3DOF / 6DOF / 3DOF Carina)
- Tracking stability (6DOF only)
- Live pose: Roll, Pitch, Yaw (degrees) and Position x/y/z (metres, 6DOF)
- Device state: Brightness, Volume, Electrochromic Film, SN hash (SHA-256 of the serial number)

Keyboard shortcuts are shown at the bottom of the screen.

## Coordinate system

raylib uses a right-handed Y-up coordinate system:

```
       Y (up)
       |
       |_____ X (right)
      /
     Z (back / toward viewer)
```

Pose data from `get_gl_pose_carina` is delivered in the same convention.
Gen1/Gen2 IMU data (NWU frame) is remapped to match before rendering.

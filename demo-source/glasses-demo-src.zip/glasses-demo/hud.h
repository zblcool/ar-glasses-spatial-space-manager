// Copyright (C) 2026 Viture Inc. All rights reserved.

#pragma once

#include <cmath>
#include <cstdio>
#include <vector>

#include "imu_state.h"
#include "raylib.h"
#include "viture_glasses_constants.h"
#include "viture_glasses_provider.h"

// ---- device helpers ---------------------------------------------------------

inline const char* device_type_label(int t)
{
    switch (t) {
        case XR_DEVICE_TYPE_VITURE_GEN1:   return "Gen1";
        case XR_DEVICE_TYPE_VITURE_GEN2:   return "Gen2";
        case XR_DEVICE_TYPE_VITURE_CARINA: return "Carina";
        default:                            return "Unknown";
    }
}

inline bool is_gen1_or_gen2(int t)
{
    return t == XR_DEVICE_TYPE_VITURE_GEN1 || t == XR_DEVICE_TYPE_VITURE_GEN2;
}

// Wraps the SDK capability query so call sites don't need to deal with the
// 0/1 int return. Gates the native-DOF code path (currently Beast).
inline bool supports_native_dof(int product_id)
{
    return xr_device_provider_is_product_support_native_dof(product_id) != 0;
}

// ---- HUD screens ------------------------------------------------------------

inline void draw_scanning_hud()
{
    const int x = 20;
    int y = 20;

    DrawText("Viture SDK Demo", x, y, 32, WHITE);
    y += 60;

    DrawText("No Viture device found.", x, y, 22, ORANGE);
    y += 34;
    DrawText("Make sure the glasses are connected over USB.", x, y, 18, GRAY);

    DrawText("[R] Scan again   [P] Toggle fullscreen   [Q / ESC] Quit", x, GetScreenHeight() - 48, 18, DARKGRAY);
}

inline void draw_selecting_dev_hud(const std::vector<int>& pids)
{
    const int x = 20;
    int y = 20;

    DrawText("Viture SDK Demo", x, y, 32, WHITE);
    y += 60;

    char buf[128];
    snprintf(buf, sizeof(buf), "Found %zu device(s). Select one to connect:", pids.size());
    DrawText(buf, x, y, 22, YELLOW);
    y += 44;

    for (int i = 0; i < static_cast<int>(pids.size()) && i < 9; ++i) {
        char name[64] = {};
        int  len = static_cast<int>(sizeof(name));
        xr_device_provider_get_market_name(pids[i], name, &len);
        snprintf(buf, sizeof(buf), "[%d]  Viture %s  (PID 0x%04X)", i + 1, name, pids[i]);
        DrawText(buf, x, y, 22, RAYWHITE);
        y += 34;
    }

    DrawText("[P] Toggle fullscreen   [Q / ESC] Quit", x, GetScreenHeight() - 48, 18, DARKGRAY);
}

inline void draw_carina_select_hud(const char* market_name)
{
    const int x = 20;
    int y = 20;

    DrawText("Viture SDK Demo", x, y, 32, WHITE);
    y += 50;

    char buf[128];
    snprintf(buf, sizeof(buf), "Device: Viture %s  |  Carina", market_name);
    DrawText(buf, x, y, 22, LIGHTGRAY);
    y += 60;

    DrawText("Select tracking mode:", x, y, 24, YELLOW);
    y += 44;
    DrawText("[3]  3DOF  —  orientation only", x, y, 22, RAYWHITE);
    y += 34;
    DrawText("[6]  6DOF  —  full position + orientation", x, y, 22, RAYWHITE);

    DrawText("[P] Toggle fullscreen   [Q / ESC] Quit", x, GetScreenHeight() - 48, 18, DARKGRAY);
}

inline void draw_native_select_hud(const char* market_name)
{
    const int x = 20;
    int y = 20;

    DrawText("Viture SDK Demo", x, y, 32, WHITE);
    y += 50;

    char buf[128];
    snprintf(buf, sizeof(buf), "Device: Viture %s", market_name);
    DrawText(buf, x, y, 22, LIGHTGRAY);
    y += 60;

    DrawText("Select 3DOF source:", x, y, 24, YELLOW);
    y += 44;
    DrawText("[1]  On-device  —  native mode, glasses track & reproject", x, y, 22, RAYWHITE);
    y += 34;
    DrawText("[2]  On-host    —  bypass mode, host renders from pose data", x, y, 22, RAYWHITE);

    DrawText("[P] Toggle fullscreen   [Q / ESC] Quit", x, GetScreenHeight() - 48, 18, DARKGRAY);
}

inline void draw_disconnected_hud()
{
    const int x = 20;
    int y = 20;

    DrawText("Viture SDK Demo", x, y, 32, WHITE);
    y += 60;

    DrawText("Device disconnected.", x, y, 22, RED);

    DrawText("[R] Scan again   [P] Toggle fullscreen   [Q / ESC] Quit", x, GetScreenHeight() - 48, 18, DARKGRAY);
}

inline void draw_tracking_hud(const float local_euler[3],
                               const float local_pos[3],
                               const float local_cquat[4],
                               bool have_pose,
                               int brightness, int volume, int film,
                               bool tracking_stable,
                               const char* market_name,
                               const char* sn_hash,
                               int device_type,
                               int product_id,
                               bool carina_6dof,
                               bool native_on_device,
                               float yaw_offset,
                               bool camera_supported,
                               bool camera_on,
                               bool exposure_manual,
                               float exposure_time_ms,
                               int exposure_gain)
{
    const int x = 20;
    int y = 20;

    DrawText("Viture SDK Demo", x, y, 32, WHITE);
    y += 50;

    char buf[128];
    snprintf(buf, sizeof(buf), "Device: Viture %s  |  %s",
             market_name, device_type_label(device_type));
    DrawText(buf, x, y, 22, LIGHTGRAY);
    y += 44;

    // ---- pose section ----
    if (supports_native_dof(product_id) && native_on_device) {
        // Native-DOF devices in on-device mode: head tracking handled by the
        // glasses themselves.
        DrawText("Mode: On-device 3DOF (native)", x, y, 20, GREEN);
        y += 28;
        DrawText("Glasses reproject the rendered frame using on-board IMU.",
                 x, y, 18, GRAY);
        y += 34;
    } else if (is_gen1_or_gen2(device_type)) {
        if (supports_native_dof(product_id))
            DrawText("Mode: On-host 3DOF (bypass)", x, y, 20, GREEN);
        else
            DrawText("Mode: 3DOF", x, y, 20, GREEN);
        y += 34;
        if (have_pose) {
            snprintf(buf, sizeof(buf), "Roll  %+7.1f deg   Pitch %+7.1f deg",
                     local_euler[0], local_euler[1]);
            DrawText(buf, x, y, 20, RAYWHITE);
            y += 28;
            snprintf(buf, sizeof(buf), "Yaw   %+7.1f deg", local_euler[2] - yaw_offset);
            DrawText(buf, x, y, 20, RAYWHITE);
            y += 34;
        } else {
            DrawText("Waiting for IMU...", x, y, 20, GRAY);
            y += 34;
        }
    } else if (device_type == XR_DEVICE_TYPE_VITURE_CARINA) {
        if (carina_6dof) {
            DrawText("Mode: 6DOF", x, y, 20, GREEN);
            y += 34;
            if (tracking_stable) {
                DrawText("Tracking: stable", x, y, 20, GREEN);
            } else {
                DrawText("Tracking: unstable — scene hidden", x, y, 20, ORANGE);
            }
            y += 28;
            if (have_pose) {
                snprintf(buf, sizeof(buf),
                         "Pos   x=%+.3f  y=%+.3f  z=%+.3f  m",
                         local_pos[0], local_pos[1], local_pos[2]);
                DrawText(buf, x, y, 20, RAYWHITE);
                y += 28;
                Vector3 fwd = QuatRotateVec3(local_cquat, {0.0f, 0.0f, -1.0f});
                float disp_yaw   = RAD2DEG * atan2f(fwd.x, -fwd.z);
                float disp_pitch = RAD2DEG * asinf(fwd.y);
                snprintf(buf, sizeof(buf),
                         "Yaw   %+7.1f deg   Pitch %+7.1f deg", disp_yaw, disp_pitch);
                DrawText(buf, x, y, 20, RAYWHITE);
                y += 34;
            } else {
                DrawText("Waiting for pose...", x, y, 20, GRAY);
                y += 34;
            }
        } else {
            DrawText("Mode: 3DOF (Carina)", x, y, 20, GREEN);
            y += 34;
            if (have_pose) {
                Vector3 fwd = QuatRotateVec3(local_cquat, {0.0f, 0.0f, -1.0f});
                float disp_yaw   = RAD2DEG * atan2f(fwd.x, -fwd.z);
                float disp_pitch = RAD2DEG * asinf(fwd.y);
                snprintf(buf, sizeof(buf),
                         "Yaw   %+7.1f deg   Pitch %+7.1f deg", disp_yaw, disp_pitch);
                DrawText(buf, x, y, 20, RAYWHITE);
                y += 34;
            } else {
                DrawText("Waiting for pose...", x, y, 20, GRAY);
                y += 34;
            }
        }
    }

    // ---- device state section ----
    y += 6;
    DrawLine(x, y, x + 480, y, DARKGRAY);
    y += 12;

    auto fmt_val = [&](const char* label, int val) {
        if (val < 0)
            snprintf(buf, sizeof(buf), "%s  --", label);
        else
            snprintf(buf, sizeof(buf), "%s  %d", label, val);
        DrawText(buf, x, y, 20, LIGHTGRAY);
        y += 28;
    };

    fmt_val("Brightness", brightness);
    fmt_val("Volume    ", volume);

    if (film < 0)
        snprintf(buf, sizeof(buf), "Film      --");
    else
        snprintf(buf, sizeof(buf), "Film      %s  (%d)", film == 0 ? "Off" : "On", film);
    DrawText(buf, x, y, 20, LIGHTGRAY);
    y += 28;

    snprintf(buf, sizeof(buf), "SN hash   %s", sn_hash[0] ? sn_hash : "--");
    DrawText(buf, x, y, 20, LIGHTGRAY);
    y += 28;

    if (camera_supported) {
        snprintf(buf, sizeof(buf), "Camera    %s", camera_on ? "On" : "Off");
        DrawText(buf, x, y, 20, camera_on ? GREEN : LIGHTGRAY);
        y += 28;
    }

    if (device_type == XR_DEVICE_TYPE_VITURE_CARINA) {
        if (exposure_manual)
            snprintf(buf, sizeof(buf), "Exposure  Manual  %.2f ms  gain %d", exposure_time_ms, exposure_gain);
        else
            snprintf(buf, sizeof(buf), "Exposure  Auto");
        DrawText(buf, x, y, 20, LIGHTGRAY);
        y += 28;
    }

    // ---- shortcuts ----
    char shortcuts[320];
    if (device_type == XR_DEVICE_TYPE_VITURE_CARINA) {
        snprintf(shortcuts, sizeof(shortcuts),
                 "[R] Recenter   [T] Reset Origin   [Y] Reset Pose   [S] Switch Mode   "
                 "[C] Stereo Cam   %s[E] Exposure Auto/Man   [ [ / ] ] Time   [ - / = ] Gain   "
                 "[P] Toggle fullscreen   [Q / ESC] Quit",
                 camera_supported ? "[W] Camera   " : "");
    } else if (supports_native_dof(product_id)) {
        snprintf(shortcuts, sizeof(shortcuts),
                 "[R] Recenter   [S] Switch Mode   %s[P] Toggle fullscreen   [Q / ESC] Quit",
                 camera_supported ? "[W] Camera   " : "");
    } else {
        snprintf(shortcuts, sizeof(shortcuts),
                 "[R] Recenter   %s[P] Toggle fullscreen   [Q / ESC] Quit",
                 camera_supported ? "[W] Camera   " : "");
    }
    DrawText(shortcuts, x, GetScreenHeight() - 48, 18, DARKGRAY);
}

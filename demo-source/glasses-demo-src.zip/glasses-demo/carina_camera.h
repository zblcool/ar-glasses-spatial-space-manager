// Copyright (C) 2026 Viture Inc. All rights reserved.

#pragma once

#include <atomic>
#include <cstdint>
#include <mutex>
#include <vector>

#include "raylib.h"
#include "viture_device_carina.h"

/**
 * carina_camera — displays the Luma Ultra VIO stereo grayscale camera.
 *
 * The Carina VIO engine captures the camera callback pointer at start time, so
 * carina_camera_register() must run before xr_device_provider_start(). Each
 * callback delivers two stereo pairs; we keep the first (frame 0) and copy it
 * only while the preview is enabled.
 *
 * The main thread uploads the latest left/right planes to two grayscale
 * textures in carina_camera_update() and draws them as small side-by-side
 * previews in carina_camera_draw().
 *
 * NOTE: defines a static global (g_carina_cam); include from one TU (main.cpp).
 */

struct CarinaCameraState {
    // Written by the Carina camera callback thread, read by the main thread.
    std::mutex           mtx;
    std::vector<uint8_t> left;
    std::vector<uint8_t> right;
    int                  width    = 0;
    int                  height   = 0;
    uint32_t             sequence = 0;

    // Main thread only.
    uint32_t  last_uploaded = 0;
    Texture2D tex_left      = {};
    Texture2D tex_right     = {};
    bool      has_tex       = false;

    // Toggled by the [C] key; gates both frame copies and drawing.
    std::atomic<bool> enabled{false};
};

static CarinaCameraState g_carina_cam;

// Carina delivers two stereo pairs per callback; we display the first (frame 0).
static void carina_camera_cb(char* left0, char* right0,
                             char* /*left1*/, char* /*right1*/,
                             double /*timestamp*/, int width, int height)
{
    if (!g_carina_cam.enabled) return;
    int size = width * height;
    if (size <= 0 || !left0 || !right0) return;
    std::lock_guard<std::mutex> lk(g_carina_cam.mtx);
    g_carina_cam.left.assign(reinterpret_cast<uint8_t*>(left0),
                             reinterpret_cast<uint8_t*>(left0) + size);
    g_carina_cam.right.assign(reinterpret_cast<uint8_t*>(right0),
                              reinterpret_cast<uint8_t*>(right0) + size);
    g_carina_cam.width    = width;
    g_carina_cam.height   = height;
    g_carina_cam.sequence++;
}

// Register the stereo camera callback. MUST be called before
// xr_device_provider_start (the VIO engine captures the pointer at start time).
// pose/vsync/imu are null — pose comes from the poll thread.
inline void carina_camera_register(XRDeviceProviderHandle handle)
{
    xr_device_provider_register_callbacks_carina(handle, nullptr, nullptr, nullptr,
                                                 carina_camera_cb);
}

inline bool carina_camera_is_on() { return g_carina_cam.enabled; }

// Enable or disable the preview. Disabling releases the GPU textures and clears
// the pending frame buffers so streaming work stops at the callback.
inline void carina_camera_set(bool on)
{
    if (on) {
        g_carina_cam.enabled = true;
        return;
    }

    g_carina_cam.enabled = false;
    if (g_carina_cam.has_tex) {
        UnloadTexture(g_carina_cam.tex_left);
        UnloadTexture(g_carina_cam.tex_right);
        g_carina_cam.tex_left  = {};
        g_carina_cam.tex_right = {};
        g_carina_cam.has_tex   = false;
    }
    std::lock_guard<std::mutex> lk(g_carina_cam.mtx);
    g_carina_cam.left.clear();
    g_carina_cam.right.clear();
    g_carina_cam.sequence      = 0;
    g_carina_cam.last_uploaded = 0;
}

inline void carina_camera_toggle() { carina_camera_set(!g_carina_cam.enabled); }

// Upload the latest stereo frame to GPU. Must be called from the main (render)
// thread each frame, inside BeginDrawing(). Returns true if textures are ready.
inline bool carina_camera_update()
{
    if (!g_carina_cam.enabled) return false;

    std::vector<uint8_t> l, r;
    int w, h;
    {
        std::lock_guard<std::mutex> lk(g_carina_cam.mtx);
        if (g_carina_cam.sequence == g_carina_cam.last_uploaded ||
            g_carina_cam.left.empty() || g_carina_cam.right.empty())
            return g_carina_cam.has_tex;
        l = g_carina_cam.left;   // copy under lock; upload outside
        r = g_carina_cam.right;
        w = g_carina_cam.width;
        h = g_carina_cam.height;
        g_carina_cam.last_uploaded = g_carina_cam.sequence;
    }

    Image img_l = { l.data(), w, h, 1, PIXELFORMAT_UNCOMPRESSED_GRAYSCALE };
    Image img_r = { r.data(), w, h, 1, PIXELFORMAT_UNCOMPRESSED_GRAYSCALE };

    if (!g_carina_cam.has_tex) {
        g_carina_cam.tex_left  = LoadTextureFromImage(img_l);
        g_carina_cam.tex_right = LoadTextureFromImage(img_r);
        g_carina_cam.has_tex =
            (g_carina_cam.tex_left.id > 0 && g_carina_cam.tex_right.id > 0);
    } else {
        UpdateTexture(g_carina_cam.tex_left,  l.data());
        UpdateTexture(g_carina_cam.tex_right, r.data());
    }
    return g_carina_cam.has_tex;
}

// Draw the two grayscale previews side by side in the top-right corner.
// Call after the 3D scene, before the HUD text.
inline void carina_camera_draw()
{
    if (!g_carina_cam.has_tex) return;

    const float ph  = 160.0f;  // preview height
    const float gap = 8.0f;
    float aspect = (g_carina_cam.height > 0)
                   ? static_cast<float>(g_carina_cam.width) / g_carina_cam.height
                   : 1.0f;
    float pw    = ph * aspect;
    float total = pw * 2 + gap;
    float x0    = GetScreenWidth() - total - 16.0f;
    float y0    = 16.0f;

    Rectangle src_l = { 0, 0, static_cast<float>(g_carina_cam.tex_left.width),
                              static_cast<float>(g_carina_cam.tex_left.height) };
    Rectangle src_r = { 0, 0, static_cast<float>(g_carina_cam.tex_right.width),
                              static_cast<float>(g_carina_cam.tex_right.height) };
    Rectangle dst_l = { x0,            y0, pw, ph };
    Rectangle dst_r = { x0 + pw + gap, y0, pw, ph };
    DrawTexturePro(g_carina_cam.tex_left,  src_l, dst_l, { 0, 0 }, 0.0f, WHITE);
    DrawTexturePro(g_carina_cam.tex_right, src_r, dst_r, { 0, 0 }, 0.0f, WHITE);
}
